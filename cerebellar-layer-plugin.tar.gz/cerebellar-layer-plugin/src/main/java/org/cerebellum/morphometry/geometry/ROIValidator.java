package org.cerebellum.morphometry.geometry;

import ij.ImagePlus;
import ij.gui.PolygonRoi;
import ij.gui.Roi;
import ij.plugin.frame.RoiManager;
import org.cerebellum.morphometry.model.LayerSet;
import org.cerebellum.morphometry.model.ValidationException;

import java.util.ArrayList;
import java.util.List;

/**
 * Checks that the RoiManager contains exactly what the plugin needs and turns the ROIs
 * into a {@link LayerSet}. Every problem found is collected and reported together.
 *
 * <h2>ROI naming — full names and abbreviations</h2>
 * Matching is case-insensitive. Both long-form names and common lab abbreviations are
 * recognised. Abbreviations are matched as <em>whole tokens</em> (surrounded by
 * non-alphanumeric characters or at the start/end of the name) so that, for example,
 * "cb" matches a ROI named "CB" or "CB_left" but not one named "2Cb" (a lobule label).
 *
 * <table border="1">
 *   <tr><th>ROI</th><th>Accepted names (examples)</th></tr>
 *   <tr><td>Cerebellum</td>
 *       <td>cerebellum, Cerebellum, <b>CB</b>, cb</td></tr>
 *   <tr><td>Granular Layer + White Matter</td>
 *       <td>granular, Granular+WM, GranularWM, <b>GL+WM</b>, GL_WM, GL WM, GLWM,
 *           gl+wm, GL (when WM is also present in the name)</td></tr>
 *   <tr><td>White Matter</td>
 *       <td>WhiteMatter, white matter, <b>WM</b>, wm</td></tr>
 *   <tr><td>Purkinje line</td>
 *       <td>purkinje, Purkinje, <b>PL</b>, pl</td></tr>
 *   <tr><td>Fissure lines (×7)</td>
 *       <td>fissure1..fissure7, Fissure_1, <b>FL1..FL7</b>, fl1..fl7, FL_1, FL-2, FL</td></tr>
 * </table>
 *
 * <p><b>Disambiguation priority</b> (important for abbreviations that could match more
 * than one category): Fissure &gt; Purkinje &gt; Granular+WM &gt; Cerebellum &gt; White Matter.
 * In particular, Granular+WM is tested before White Matter, so a ROI named "GL+WM" is
 * correctly identified as Granular+WM even though it also contains the "wm" token.</p>
 */
public final class ROIValidator {

    /** How far a containment check may be off, as a fraction of area. */
    private static final double CONTAINMENT_TOLERANCE_FRACTION = 0.005; // 0.5 %

    private ROIValidator() {
    }

    // -----------------------------------------------------------------------
    // Public entry point
    // -----------------------------------------------------------------------

    public static LayerSet validate(RoiManager rm, ImagePlus imp) throws ValidationException {
        List<String> problems = new ArrayList<>();

        if (rm == null || rm.getCount() == 0) {
            problems.add("The ROI Manager is empty. Add the Cerebellum (or CB), Granular+WM (or GL+WM), "
                    + "WhiteMatter (or WM), Purkinje line (or PL), and seven Fissure lines "
                    + "(FL1–FL7) before running this plugin.");
            throw new ValidationException(problems);
        }
        if (imp == null) {
            problems.add("No active image. Open the Nissl-stained section this plugin should measure.");
            throw new ValidationException(problems);
        }

        Roi[] rois = rm.getRoisAsArray();

        Roi cerebellum = null;
        Roi granularWM = null;
        Roi whiteMatter = null;
        Roi purkinje    = null;
        List<Roi> fissures = new ArrayList<>();
        List<String> duplicateNames = new ArrayList<>();

        // -------------------------------------------------------------------
        // Dispatch — evaluated in priority order: Fissure > Purkinje >
        // GranularWM > Cerebellum > WhiteMatter.  GranularWM MUST come before
        // WhiteMatter so that "GL+WM" is not mistakenly classified as WM.
        // -------------------------------------------------------------------
        for (Roi roi : rois) {
            String name  = roi.getName() == null ? "" : roi.getName();
            String lower = name.toLowerCase();

            if (matchesFissure(lower)) {
                fissures.add(roi);

            } else if (matchesPurkinje(lower)) {
                if (purkinje != null) {
                    duplicateNames.add("Purkinje (\"" + purkinje.getName() + "\" and \"" + name + "\")");
                }
                purkinje = roi;

            } else if (matchesGranularWM(lower)) {
                if (granularWM != null) {
                    duplicateNames.add("Granular+WM (\"" + granularWM.getName() + "\" and \"" + name + "\")");
                }
                granularWM = roi;

            } else if (matchesCerebellum(lower)) {
                if (cerebellum != null) {
                    duplicateNames.add("Cerebellum (\"" + cerebellum.getName() + "\" and \"" + name + "\")");
                }
                cerebellum = roi;

            } else if (matchesWhiteMatter(lower)) {
                if (whiteMatter != null) {
                    duplicateNames.add("WhiteMatter (\"" + whiteMatter.getName() + "\" and \"" + name + "\")");
                }
                whiteMatter = roi;
            }
        }

        // -------------------------------------------------------------------
        // Collect problems — duplicates first, then missing/wrong-type checks.
        // -------------------------------------------------------------------
        for (String dup : duplicateNames) {
            problems.add("More than one ROI matches " + dup + " — rename or remove one.");
        }

        if (cerebellum == null) {
            problems.add("Missing the Cerebellum ROI. "
                    + "Add a closed polygon whose name contains \"cerebellum\" or the abbreviation \"CB\".");
        } else if (isLineType(cerebellum)) {
            problems.add("The Cerebellum ROI (\"" + cerebellum.getName()
                    + "\") is a polyline, not a closed area. Retrace it as a closed polygon.");
        }

        if (granularWM == null) {
            problems.add("Missing the Granular+WM ROI. "
                    + "Add a closed polygon whose name contains \"granular\", \"GL+WM\", \"GLWM\", or similar.");
        } else if (isLineType(granularWM)) {
            problems.add("The Granular+WM ROI (\"" + granularWM.getName()
                    + "\") is a polyline, not a closed area. Retrace it as a closed polygon.");
        }

        if (whiteMatter == null) {
            problems.add("Missing the White Matter ROI. "
                    + "Add a closed polygon whose name contains \"white\" or the abbreviation \"WM\" "
                    + "(alone — not as part of \"GL+WM\", which is the Granular+WM ROI).");
        } else if (isLineType(whiteMatter)) {
            problems.add("The WhiteMatter ROI (\"" + whiteMatter.getName()
                    + "\") is a polyline, not a closed area. Retrace it as a closed polygon.");
        }

        if (purkinje == null) {
            problems.add("Missing the Purkinje ROI. "
                    + "Add an open polyline whose name contains \"purkinje\" or the abbreviation \"PL\".");
        } else if (!isLineType(purkinje)) {
            problems.add("The Purkinje ROI (\"" + purkinje.getName()
                    + "\") is a closed area, not a polyline. Retrace it as an open polyline.");
        } else if (!(purkinje instanceof PolygonRoi)) {
            problems.add("The Purkinje ROI (\"" + purkinje.getName()
                    + "\") could not be read as a polyline.");
        }

        if (fissures.size() != 7) {
            problems.add("Expected exactly 7 fissure ROIs, found " + fissures.size() + ". "
                    + "Name them with \"fissure\" or the abbreviations FL1–FL7 (e.g. FL1, FL2, … FL7).");
        }
        List<PolygonRoi> fissurePolylines = new ArrayList<>();
        for (Roi f : fissures) {
            if (!isLineType(f)) {
                problems.add("Fissure ROI \"" + f.getName()
                        + "\" is a closed area, not a polyline. Retrace it as an open polyline.");
            } else if (!(f instanceof PolygonRoi)) {
                problems.add("Fissure ROI \"" + f.getName() + "\" could not be read as a polyline.");
            } else {
                fissurePolylines.add((PolygonRoi) f);
            }
        }

        // Containment checks (only run when the relevant ROIs are confirmed present and area-typed).
        if (cerebellum != null && granularWM != null
                && !isLineType(cerebellum) && !isLineType(granularWM)) {
            double granularWMArea = BooleanROIProcessor.area(granularWM, imp);
            double outside = BooleanROIProcessor.area(
                    BooleanROIProcessor.subtract(granularWM, cerebellum), imp);
            if (!withinTolerance(outside, granularWMArea)) {
                problems.add("The Granular+WM ROI is not fully inside the Cerebellum ROI "
                        + "(~" + percentOutside(outside, granularWMArea) + "% falls outside).");
            }
        }
        if (granularWM != null && whiteMatter != null
                && !isLineType(granularWM) && !isLineType(whiteMatter)) {
            double whiteMatterArea = BooleanROIProcessor.area(whiteMatter, imp);
            double outside = BooleanROIProcessor.area(
                    BooleanROIProcessor.subtract(whiteMatter, granularWM), imp);
            if (!withinTolerance(outside, whiteMatterArea)) {
                problems.add("The WhiteMatter ROI is not fully inside the Granular+WM ROI "
                        + "(~" + percentOutside(outside, whiteMatterArea) + "% falls outside).");
            }
        }

        if (!problems.isEmpty()) {
            throw new ValidationException(problems);
        }

        return new LayerSet(cerebellum, granularWM, whiteMatter,
                (PolygonRoi) purkinje, fissurePolylines);
    }

    // -----------------------------------------------------------------------
    // Name-matching predicates
    // -----------------------------------------------------------------------

    /**
     * Cerebellum: "cerebellum" anywhere, OR whole-word "cb".
     * Whole-word guards against lobule labels like "2Cb" being mistaken for
     * the whole-cerebellum outline.
     */
    private static boolean matchesCerebellum(String lower) {
        return lower.contains("cerebellum") || isWholeWord(lower, "cb");
    }

    /**
     * Granular + White Matter: "granular" anywhere; compound abbreviations
     * GL+WM / GLWM / GL_WM / GL-WM / GL WM; or whole-word "GL" co-occurring
     * with whole-word "WM" anywhere in the same name.
     * This predicate MUST be evaluated before {@link #matchesWhiteMatter} so
     * that a name like "GL+WM" is not misclassified as the White Matter ROI.
     */
    private static boolean matchesGranularWM(String lower) {
        if (lower.contains("granular")) return true;
        if (lower.contains("gl+wm") || lower.contains("glwm")
                || lower.contains("gl_wm") || lower.contains("gl-wm")
                || lower.contains("gl wm")) return true;
        // Whole-word "gl" together with whole-word "wm" anywhere in the name.
        return isWholeWord(lower, "gl") && isWholeWord(lower, "wm");
    }

    /**
     * White Matter: "white" anywhere, OR whole-word "wm".
     * Because the dispatch chain tests Granular+WM first, a name like "GL+WM"
     * never reaches this predicate.
     */
    private static boolean matchesWhiteMatter(String lower) {
        return lower.contains("white") || isWholeWord(lower, "wm");
    }

    /**
     * Purkinje: "purkinje" anywhere, OR whole-word "pl"
     * (Purkinje Layer / Purkinje Line).
     */
    private static boolean matchesPurkinje(String lower) {
        return lower.contains("purkinje") || isWholeWord(lower, "pl");
    }

    /**
     * Fissure: "fissure" anywhere; whole-word "fl"; or "fl" at a word boundary
     * followed by a non-letter (covers FL1, FL2, … FL7, FL_1, FL-2, etc.).
     */
    private static boolean matchesFissure(String lower) {
        if (lower.contains("fissure")) return true;
        if (isWholeWord(lower, "fl"))  return true;
        return matchesFLNumbered(lower);
    }

    /**
     * Returns true when "fl" appears at a word boundary and is immediately
     * followed by a non-letter character (digit, underscore, hyphen, space, …).
     * This matches FL1 / FL_1 / FL-1 / "fl 1" but not words like "flat".
     */
    private static boolean matchesFLNumbered(String lower) {
        int idx = 0;
        while ((idx = lower.indexOf("fl", idx)) >= 0) {
            boolean beforeOk = idx == 0
                    || !Character.isLetterOrDigit(lower.charAt(idx - 1));
            int afterIdx = idx + 2;
            boolean afterOk = afterIdx < lower.length()
                    && !Character.isLetter(lower.charAt(afterIdx));
            if (beforeOk && afterOk) return true;
            idx++;
        }
        return false;
    }

    // -----------------------------------------------------------------------
    // Shared helpers
    // -----------------------------------------------------------------------

    /**
     * Returns true when {@code token} appears in {@code lower} as a complete
     * word — bounded by non-alphanumeric characters or string start/end.
     * Examples: isWholeWord("cb_outline", "cb") → true,
     *           isWholeWord("2cb", "cb")        → false (preceded by digit).
     */
    private static boolean isWholeWord(String lower, String token) {
        int idx = 0;
        while ((idx = lower.indexOf(token, idx)) >= 0) {
            boolean beforeOk = idx == 0
                    || !Character.isLetterOrDigit(lower.charAt(idx - 1));
            boolean afterOk  = (idx + token.length() >= lower.length())
                    || !Character.isLetterOrDigit(lower.charAt(idx + token.length()));
            if (beforeOk && afterOk) return true;
            idx++;
        }
        return false;
    }

    private static boolean isLineType(Roi roi) {
        int type = roi.getType();
        return type == Roi.LINE || type == Roi.POLYLINE || type == Roi.FREELINE;
    }

    private static boolean withinTolerance(double outsideArea, double referenceArea) {
        double tolerance = Math.max(referenceArea * CONTAINMENT_TOLERANCE_FRACTION, 1e-9);
        return outsideArea <= tolerance;
    }

    private static String percentOutside(double outsideArea, double referenceArea) {
        if (referenceArea <= 0) return "?";
        return String.format("%.1f", 100.0 * outsideArea / referenceArea);
    }
}
