package org.cerebellum.morphometry.geometry;

import ij.gui.Roi;

import ij.gui.Roi;

import java.awt.*;
import java.awt.geom.Point2D;

/**
 * Vector-math and polyline utilities used by {@link FissurePartitioner} and
 * {@link PurkinjeLengthCalculator}. Everything here works in image/pixel coordinate
 * space (the same space Roi vertex coordinates are stored in) &mdash; calibration to
 * physical units is applied separately, only at the point of measurement.
 */
public final class GeometryUtils {

    private GeometryUtils() {
    }

    /** Extracts a Roi's vertices (works for polygons, polylines, and simple shapes alike). */
    public static Point2D.Double[] extractPoints(Roi roi) {
        var fp = roi.getFloatPolygon();
        Point2D.Double[] pts = new Point2D.Double[fp.npoints];
        for (int i = 0; i < fp.npoints; i++) {
            pts[i] = new Point2D.Double(fp.xpoints[i], fp.ypoints[i]);
        }
        return pts;
    }

    /** Cumulative path length at each vertex: result[0] == 0, result[n-1] == total length. */
    public static double[] cumulativeLengths(Point2D.Double[] points) {
        double[] cum = new double[points.length];
        for (int i = 1; i < points.length; i++) {
            cum[i] = cum[i - 1] + points[i - 1].distance(points[i]);
        }
        return cum;
    }

    /** Result of projecting a point onto a polyline: how far along it, and how close the match was. */
    public static final class Projection {
        public final double arcLength;
        public final double distance;

        public Projection(double arcLength, double distance) {
            this.arcLength = arcLength;
            this.distance = distance;
        }
    }

    /**
     * Projects {@code query} onto the polyline defined by {@code points}, returning both the
     * arc-length (using the precomputed {@code cumulative} lengths) and the distance of the
     * closest point on the polyline. Used to find where a fissure attaches along the Purkinje
     * line, and to sanity-check how close that attachment actually is.
     */
    public static Projection project(Point2D.Double[] points, double[] cumulative, Point2D.Double query) {
        double bestDist = Double.POSITIVE_INFINITY;
        double bestArc = 0;
        for (int i = 0; i < points.length - 1; i++) {
            Point2D.Double a = points[i];
            Point2D.Double b = points[i + 1];
            double segDx = b.x - a.x;
            double segDy = b.y - a.y;
            double segLenSq = segDx * segDx + segDy * segDy;
            double t = segLenSq < 1e-12 ? 0.0
                    : ((query.x - a.x) * segDx + (query.y - a.y) * segDy) / segLenSq;
            t = Math.max(0.0, Math.min(1.0, t));
            double px = a.x + t * segDx;
            double py = a.y + t * segDy;
            double dist = Point2D.distance(query.x, query.y, px, py);
            if (dist < bestDist) {
                bestDist = dist;
                bestArc = cumulative[i] + t * Math.sqrt(segLenSq);
            }
        }
        return new Projection(bestArc, bestDist);
    }

    public static Point2D.Double subtract(Point2D.Double a, Point2D.Double b) {
        return new Point2D.Double(a.x - b.x, a.y - b.y);
    }

    public static Point2D.Double add(Point2D.Double a, Point2D.Double b) {
        return new Point2D.Double(a.x + b.x, a.y + b.y);
    }

    public static Point2D.Double scale(Point2D.Double v, double s) {
        return new Point2D.Double(v.x * s, v.y * s);
    }

    public static double length(Point2D.Double v) {
        return Math.sqrt(v.x * v.x + v.y * v.y);
    }

    /** Unit vector in the direction of v; returns (1,0) for a zero/near-zero vector as a safe fallback. */
    public static Point2D.Double normalize(Point2D.Double v) {
        double len = length(v);
        if (len < 1e-9) {
            return new Point2D.Double(1, 0);
        }
        return new Point2D.Double(v.x / len, v.y / len);
    }

    /** 90-degree counter-clockwise rotation (in image coordinates, where y grows downward). */
    public static Point2D.Double perpendicular(Point2D.Double v) {
        return new Point2D.Double(-v.y, v.x);
    }

    /** Arithmetic centroid of a Roi's polygon vertices (sufficient for direction-finding). */
    public static Point2D.Double centroid(Roi roi) {
        var fp = roi.getFloatPolygon();
        if (fp.npoints == 0) {
            return new Point2D.Double(0, 0);
        }
        double cx = 0, cy = 0;
        for (int i = 0; i < fp.npoints; i++) {
            cx += fp.xpoints[i];
            cy += fp.ypoints[i];
        }
        return new Point2D.Double(cx / fp.npoints, cy / fp.npoints);
    }

    /** Interpolates the point at the given arc-length distance along a polyline (clamped to the polyline's ends). */
    public static Point2D.Double pointAtArcLength(Point2D.Double[] points, double[] cumulative, double arc) {
        int n = points.length;
        if (arc <= 0) {
            return points[0];
        }
        if (arc >= cumulative[n - 1]) {
            return points[n - 1];
        }
        for (int i = 0; i < n - 1; i++) {
            if (cumulative[i + 1] >= arc) {
                double segLen = cumulative[i + 1] - cumulative[i];
                double t = segLen < 1e-9 ? 0 : (arc - cumulative[i]) / segLen;
                double x = points[i].x + t * (points[i + 1].x - points[i].x);
                double y = points[i].y + t * (points[i + 1].y - points[i].y);
                return new Point2D.Double(x, y);
            }
        }
        return points[n - 1];
    }

    public static double diagonal(Rectangle bounds) {
        return Math.sqrt((double) bounds.width * bounds.width + (double) bounds.height * bounds.height);
    }
}
