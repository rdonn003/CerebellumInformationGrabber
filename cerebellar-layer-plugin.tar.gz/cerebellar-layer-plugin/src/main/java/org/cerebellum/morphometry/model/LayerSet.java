package org.cerebellum.morphometry.model;

import ij.gui.PolygonRoi;
import ij.gui.Roi;

import java.util.Collections;
import java.util.List;

/**
 * The five categories of user-supplied ROI, after {@link org.cerebellum.morphometry.geometry.ROIValidator}
 * has confirmed they exist, have the right ROI type, and are correctly nested.
 *
 * <p>The seven {@link #fissures} are stored in anatomical order &mdash; sorted from the
 * end of the Purkinje line nearest lobule&nbsp;2 to the end nearest lobule&nbsp;10 &mdash;
 * which is what lets {@link org.cerebellum.morphometry.geometry.FissurePartitioner} build
 * the eight subsections without needing any left/right or compass-direction assumptions.</p>
 */
public final class LayerSet {

    private final Roi cerebellum;
    private final Roi granularWM;
    private final Roi whiteMatter;
    private final PolygonRoi purkinje;
    private final List<PolygonRoi> fissures; // size 7, anatomically ordered

    public LayerSet(Roi cerebellum, Roi granularWM, Roi whiteMatter,
                     PolygonRoi purkinje, List<PolygonRoi> fissures) {
        this.cerebellum = cerebellum;
        this.granularWM = granularWM;
        this.whiteMatter = whiteMatter;
        this.purkinje = purkinje;
        this.fissures = Collections.unmodifiableList(fissures);
    }

    public Roi getCerebellum() {
        return cerebellum;
    }

    public Roi getGranularWM() {
        return granularWM;
    }

    public Roi getWhiteMatter() {
        return whiteMatter;
    }

    public PolygonRoi getPurkinje() {
        return purkinje;
    }

    /** Seven fissure polylines, ordered from the lobule-2 end of the Purkinje line to the lobule-10 end. */
    public List<PolygonRoi> getFissures() {
        return fissures;
    }
}
