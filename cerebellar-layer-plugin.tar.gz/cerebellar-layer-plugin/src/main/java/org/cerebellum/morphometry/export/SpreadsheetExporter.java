package org.cerebellum.morphometry.export;

import ij.measure.ResultsTable;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.cerebellum.morphometry.model.MorphometryResults;

import java.io.*;
import java.util.List;

/**
 * Exports a {@link MorphometryResults} to three targets:
 * <ol>
 *   <li>An ImageJ {@link ResultsTable} (displayed interactively via {@link #showResultsTable}).</li>
 *   <li>A plain UTF-8 CSV file.</li>
 *   <li>A native {@code .xlsx} workbook via Apache POI.</li>
 * </ol>
 *
 * <p>All three reproduce the exact table layout described in the spec:</p>
 * <pre>
 * Measurement | Cerebellum | Grey Matter | Granular Layer | Molecular Layer | Purkinje
 * Area        | Total      | Grey        | Granular       | Molecular       |
 * Length      |            |             |                |                 | Total Length
 * 2Cb         |            |             | Area           | Area            | Length
 * ...
 * 10Cb        |            |             | Area           | Area            | Length
 * </pre>
 *
 * <p>All values are in the calibrated units reported by {@link MorphometryResults#getAreaUnit()} and
 * {@link MorphometryResults#getLengthUnit()}, so the numbers match whatever unit the image's
 * pixel calibration was set to (microns, millimetres, etc.).</p>
 */
public final class SpreadsheetExporter {

    // Column indices for readability
    private static final int COL_MEASUREMENT    = 0;
    private static final int COL_CEREBELLUM     = 1;
    private static final int COL_GREY           = 2;
    private static final int COL_GRANULAR       = 3;
    private static final int COL_MOLECULAR      = 4;
    private static final int COL_PURKINJE       = 5;

    // Row indices (0-based within the data region)
    private static final int ROW_HEADER         = 0;
    private static final int ROW_AREA           = 1;
    private static final int ROW_LENGTH         = 2;
    private static final int ROW_SUBSECTIONS_START = 3;

    private SpreadsheetExporter() {
    }

    // -----------------------------------------------------------------------
    // ImageJ ResultsTable
    // -----------------------------------------------------------------------

    /**
     * Builds a {@link ResultsTable} and shows it in the ImageJ UI.
     * The ResultsTable API is column-oriented, so we fake the required row-oriented layout
     * by using the "Label" column as the first (Measurement) column, and making each
     * logical column a ResultsTable column.
     */
    public static ResultsTable buildResultsTable(MorphometryResults r) {
        ResultsTable rt = new ResultsTable();
        rt.setPrecision(4);

        // Row 0: Header row (column names)
        rt.incrementCounter();
        rt.addLabel("Measurement");
        rt.addValue("Cerebellum (" + r.getAreaUnit() + ")", Double.NaN);
        rt.addValue("Grey Matter (" + r.getAreaUnit() + ")", Double.NaN);
        rt.addValue("Granular Layer (" + r.getAreaUnit() + ")", Double.NaN);
        rt.addValue("Molecular Layer (" + r.getAreaUnit() + ")", Double.NaN);
        rt.addValue("Purkinje (" + r.getLengthUnit() + ")", Double.NaN);

        // Row 1: Area totals
        rt.incrementCounter();
        rt.addLabel("Area");
        rt.addValue("Cerebellum (" + r.getAreaUnit() + ")", r.getCerebellumArea());
        rt.addValue("Grey Matter (" + r.getAreaUnit() + ")", r.getGreyMatterArea());
        rt.addValue("Granular Layer (" + r.getAreaUnit() + ")", r.getGranularLayerArea());
        rt.addValue("Molecular Layer (" + r.getAreaUnit() + ")", r.getMolecularLayerArea());
        rt.addValue("Purkinje (" + r.getLengthUnit() + ")", Double.NaN);

        // Row 2: Length
        rt.incrementCounter();
        rt.addLabel("Length");
        rt.addValue("Cerebellum (" + r.getAreaUnit() + ")", Double.NaN);
        rt.addValue("Grey Matter (" + r.getAreaUnit() + ")", Double.NaN);
        rt.addValue("Granular Layer (" + r.getAreaUnit() + ")", Double.NaN);
        rt.addValue("Molecular Layer (" + r.getAreaUnit() + ")", Double.NaN);
        rt.addValue("Purkinje (" + r.getLengthUnit() + ")", r.getTotalPurkinjeLength());

        // Rows 3–10: Per-subsection
        for (MorphometryResults.SubsectionResult sub : r.getSubsections()) {
            rt.incrementCounter();
            rt.addLabel(sub.getLabel());
            rt.addValue("Cerebellum (" + r.getAreaUnit() + ")", Double.NaN);
            rt.addValue("Grey Matter (" + r.getAreaUnit() + ")", Double.NaN);
            rt.addValue("Granular Layer (" + r.getAreaUnit() + ")", sub.getGranularArea());
            rt.addValue("Molecular Layer (" + r.getAreaUnit() + ")", sub.getMolecularArea());
            rt.addValue("Purkinje (" + r.getLengthUnit() + ")", sub.getPurkinjeLength());
        }
        return rt;
    }

    /** Builds and shows the ResultsTable in the ImageJ UI. */
    public static void showResultsTable(MorphometryResults r) {
        ResultsTable rt = buildResultsTable(r);
        rt.show("Cerebellar Morphometry");
    }

    // -----------------------------------------------------------------------
    // CSV
    // -----------------------------------------------------------------------

    public static void exportCSV(MorphometryResults r, File file) throws IOException {
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"))) {
            String[][] rows = buildDataGrid(r);
            for (String[] row : rows) {
                pw.println(escapeCSVRow(row));
            }
        }
    }

    private static String escapeCSVRow(String[] cells) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            String cell = cells[i] == null ? "" : cells[i];
            if (cell.contains(",") || cell.contains("\"") || cell.contains("\n")) {
                sb.append('"').append(cell.replace("\"", "\"\"")).append('"');
            } else {
                sb.append(cell);
            }
        }
        return sb.toString();
    }

    // -----------------------------------------------------------------------
    // XLSX
    // -----------------------------------------------------------------------

    public static void exportXLSX(MorphometryResults r, File file) throws IOException {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet sheet = wb.createSheet("Cerebellar Morphometry");

            // ---- Cell styles ----
            CellStyle headerStyle = wb.createCellStyle();
            Font headerFont = wb.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);

            CellStyle numberStyle = wb.createCellStyle();
            DataFormat df = wb.createDataFormat();
            numberStyle.setDataFormat(df.getFormat("0.0000"));

            CellStyle sectionStyle = wb.createCellStyle();
            Font sectionFont = wb.createFont();
            sectionFont.setItalic(true);
            sectionStyle.setFont(sectionFont);

            String[][] data = buildDataGrid(r);

            // Write header row with bold style
            Row header = sheet.createRow(ROW_HEADER);
            for (int c = 0; c < data[0].length; c++) {
                Cell cell = header.createCell(c);
                cell.setCellValue(data[0][c] == null ? "" : data[0][c]);
                cell.setCellStyle(headerStyle);
            }

            // Write data rows
            for (int rowIdx = 1; rowIdx < data.length; rowIdx++) {
                Row row = sheet.createRow(rowIdx);
                String[] rowData = data[rowIdx];

                // First cell (Measurement label) always as string
                Cell labelCell = row.createCell(0);
                labelCell.setCellValue(rowData[0] == null ? "" : rowData[0]);
                if (rowIdx >= ROW_SUBSECTIONS_START) {
                    labelCell.setCellStyle(sectionStyle);
                }

                // Remaining cells: numeric if parseable, otherwise string
                for (int c = 1; c < rowData.length; c++) {
                    Cell cell = row.createCell(c);
                    String val = rowData[c];
                    if (val == null || val.isEmpty()) {
                        cell.setCellValue("");
                    } else {
                        try {
                            double d = Double.parseDouble(val);
                            cell.setCellValue(d);
                            cell.setCellStyle(numberStyle);
                        } catch (NumberFormatException e) {
                            cell.setCellValue(val);
                        }
                    }
                }
            }

            // Auto-size columns
            for (int c = 0; c < data[0].length; c++) {
                sheet.autoSizeColumn(c);
            }

            // Freeze the header row and label column
            sheet.createFreezePane(1, 1);

            // Bold the area/length value rows
            for (int rowNum = ROW_AREA; rowNum <= ROW_LENGTH; rowNum++) {
                Row row = sheet.getRow(rowNum);
                if (row == null) continue;
                for (Cell cell : row) {
                    CellStyle base = cell.getCellStyle();
                    CellStyle bold = wb.createCellStyle();
                    bold.cloneStyleFrom(base);
                    Font boldFont = wb.createFont();
                    boldFont.setBold(true);
                    bold.setFont(boldFont);
                    cell.setCellStyle(bold);
                }
            }

            try (FileOutputStream fos = new FileOutputStream(file)) {
                wb.write(fos);
            }
        }
    }

    // -----------------------------------------------------------------------
    // Shared grid builder (used by both CSV and XLSX paths)
    // -----------------------------------------------------------------------

    /**
     * Returns a 2D grid of String values (null == empty cell) matching the layout
     * required by the spec. Numeric values are formatted to 4 decimal places. Both
     * CSV and XLSX callers use this so the two formats always agree.
     */
    public static String[][] buildDataGrid(MorphometryResults r) {
        List<MorphometryResults.SubsectionResult> subs = r.getSubsections();
        int nRows = ROW_SUBSECTIONS_START + subs.size(); // header + area + length + N subsections
        int nCols = 6;

        String[][] g = new String[nRows][nCols];

        // Header row
        g[ROW_HEADER][COL_MEASUREMENT] = "Measurement";
        g[ROW_HEADER][COL_CEREBELLUM]  = "Cerebellum (" + r.getAreaUnit() + ")";
        g[ROW_HEADER][COL_GREY]        = "Grey Matter (" + r.getAreaUnit() + ")";
        g[ROW_HEADER][COL_GRANULAR]    = "Granular Layer (" + r.getAreaUnit() + ")";
        g[ROW_HEADER][COL_MOLECULAR]   = "Molecular Layer (" + r.getAreaUnit() + ")";
        g[ROW_HEADER][COL_PURKINJE]    = "Purkinje (" + r.getLengthUnit() + ")";

        // Area row
        g[ROW_AREA][COL_MEASUREMENT] = "Area";
        g[ROW_AREA][COL_CEREBELLUM]  = fmt(r.getCerebellumArea());
        g[ROW_AREA][COL_GREY]        = fmt(r.getGreyMatterArea());
        g[ROW_AREA][COL_GRANULAR]    = fmt(r.getGranularLayerArea());
        g[ROW_AREA][COL_MOLECULAR]   = fmt(r.getMolecularLayerArea());
        g[ROW_AREA][COL_PURKINJE]    = null;

        // Length row
        g[ROW_LENGTH][COL_MEASUREMENT] = "Length";
        g[ROW_LENGTH][COL_CEREBELLUM]  = null;
        g[ROW_LENGTH][COL_GREY]        = null;
        g[ROW_LENGTH][COL_GRANULAR]    = null;
        g[ROW_LENGTH][COL_MOLECULAR]   = null;
        g[ROW_LENGTH][COL_PURKINJE]    = fmt(r.getTotalPurkinjeLength());

        // Per-subsection rows
        for (int i = 0; i < subs.size(); i++) {
            MorphometryResults.SubsectionResult s = subs.get(i);
            int row = ROW_SUBSECTIONS_START + i;
            g[row][COL_MEASUREMENT] = s.getLabel();
            g[row][COL_CEREBELLUM]  = null;
            g[row][COL_GREY]        = null;
            g[row][COL_GRANULAR]    = fmt(s.getGranularArea());
            g[row][COL_MOLECULAR]   = fmt(s.getMolecularArea());
            g[row][COL_PURKINJE]    = fmt(s.getPurkinjeLength());
        }

        return g;
    }

    private static String fmt(double v) {
        return String.format("%.4f", v);
    }
}
