package org.cerebellum.morphometry.visualization;

import ij.gui.PolygonRoi;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import ij.plugin.frame.RoiManager;
import org.cerebellum.morphometry.geometry.PartitionClipper;
import org.cerebellum.morphometry.geometry.PurkinjeLengthCalculator;
import org.cerebellum.morphometry.measurement.MeasurementEngine.IntermediateGeometry;
import org.cerebellum.morphometry.model.LayerSet;
import org.cerebellum.morphometry.model.PartitionSet;

import java.awt.Rectangle;
import java.util.List;

/**
 * Adds a named {@link Roi} to the ROI Manager for every number the plugin reports, so each
 * measured region can be independently re-selected, inspected, re-measured, or exported like
 * any other FIJI ROI &mdash; not just read off the results table.
 *
 * <p>This mirrors {@link org.cerebellum.morphometry.measurement.MeasurementEngine}'s numeric
 * output one-to-one:</p>
 * <ul>
 *   <li>the three whole-cerebellum layers (Grey Matter, Granular Layer, Molecular Layer);</li>
 *   <li>for each lobule that was actually resolved (see {@link PartitionSet}, which may be
 *       fewer than eight if a fissure didn't fully cross one of the layers): its clipped
 *       Granular area, clipped Molecular area, and Purkinje sub-segment.</li>
 * </ul>
 *
 * <p>Names use an underscore convention ({@code "<lobule>_Granular"}, {@code
 * "<lobule>_Molecular"}, {@code "<lobule>_Purkinje"}) rather than spaces, so they sort
 * predictably next to each other and stay friendly to downstream scripts that match on ROI
 * name. Every added ROI is a defensive copy &mdash; nothing already in the geometry pipeline
 * (used simultaneously by the overlay renderer and the results table) is mutated.</p>
 */
public final class RoiManagerExporter {

    private RoiManagerExporter() {
    }

    /**
     * Adds one ROI per measurement to {@code rm}.
     *
     * @param rm     the ROI Manager to add to (already containing the user's input ROIs)
     * @param layers validated input ROIs, needed for the whole Purkinje polyline
     * @param geo    intermediate geometry from {@link org.cerebellum.morphometry.measurement.MeasurementEngine#buildGeometry}
     */
    public static void addMeasurementRois(RoiManager rm, LayerSet layers, IntermediateGeometry geo) {
        addNamed(rm, geo.constructed.getGrey(), "Grey Matter");
        addNamed(rm, geo.constructed.getGranular(), "Granular Layer");
        addNamed(rm, geo.constructed.getMolecular(), "Molecular Layer");

        List<PartitionSet.Partition> partitions = geo.partitionSet.getPartitions();
        for (int i = 0; i < geo.clipped.size(); i++) {
            PartitionClipper.ClippedPartition cp = geo.clipped.get(i);
            PartitionSet.Partition p = partitions.get(i);

            addNamed(rm, cp.granular, cp.label + "_Granular");
            addNamed(rm, cp.molecular, cp.label + "_Molecular");

            PolygonRoi purkinjeSegment = PurkinjeLengthCalculator.extractSubPolyline(
                    layers.getPurkinje(), p.getPurkinjeArcStart(), p.getPurkinjeArcEnd());
            addNamed(rm, purkinjeSegment, cp.label + "_Purkinje");
        }
    }

    /** Defensive-copies {@code roi}, names the copy, and adds it — skipping empty/degenerate shapes. */
    private static void addNamed(RoiManager rm, Roi roi, String name) {
        if (roi == null) {
            return;
        }
        Rectangle bounds = roi.getBounds();
        if (bounds.width <= 0 || bounds.height <= 0) {
            return; // nothing to show for this measurement (e.g. a layer absent in this partition)
        }
        Roi copy = (roi instanceof ShapeRoi) ? new ShapeRoi(roi) : (Roi) roi.clone();
        copy.setName(name);
        rm.addRoi(copy);
    }
}
