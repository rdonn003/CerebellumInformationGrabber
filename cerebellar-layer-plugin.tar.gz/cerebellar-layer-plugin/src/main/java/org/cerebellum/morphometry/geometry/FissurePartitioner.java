package org.cerebellum.morphometry.geometry;

import ij.gui.PolygonRoi;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import org.cerebellum.morphometry.model.LayerSet;
import org.cerebellum.morphometry.model.PartitionSet;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Turns the seven hand-traced fissure lines into eight closed lobule regions.
 *
 * <h2>Ordering</h2>
 * Each fissure's Purkinje-line endpoint is projected onto the Purkinje polyline to get an
 * arc-length position. Sorting by that position gives the anatomical order (2Cb&rarr;10Cb)
 * without any image-orientation assumptions. The two free ends of the Purkinje polyline
 * become the outer edges of subsections 1 and 8 automatically.
 *
 * <h2>Extension strategy — why the fissure's own slope is not used</h2>
 * Each fissure only crosses the molecular layer (pial surface&rarr;Purkinje line). To split
 * the granular layer and white matter into the same eight subsections, each fissure must be
 * extended <em>inward</em> past the Purkinje line through the granular layer.
 *
 * <p>The naive approach (continue in the fissure's own pial&rarr;Purkinje direction) fails
 * on highly foliated sections because each fissure's traced slope depends on which fold the
 * user traced it through, not on the anatomy of what lies beneath the Purkinje line. A
 * fissure traced at 45&deg; extends at 45&deg; into the granular layer even if the correct
 * inward direction is nearly vertical — producing large cross-lobule errors.</p>
 *
 * <h2>Corrected inward extension — toward the white matter centroid</h2>
 * The cerebellum's foliation radiates from the central white matter core. Every fissure,
 * when extended inward past the Purkinje line, should converge toward that core. We
 * therefore extend each fissure from its Purkinje attachment point toward the centroid of
 * the White Matter ROI. This direction is anatomically correct and is independent of how
 * the user happened to angle each individual fissure trace.
 *
 * <p>The outward extension (past the pial surface) still uses the fissure's own direction —
 * it just needs to clear the bounding box and does not affect anatomical accuracy.</p>
 *
 * <h2>Cutting and assembly</h2>
 * The bent cut line (fissure vertices + inward extension) is thickened into a half-plane
 * polygon on the lobule-10 side of the cut. {@code ShapeRoi.and} with the cerebellum
 * gives the half that lies beyond each fissure. Eight partitions are consecutive
 * differences of these half-planes; per-partition Purkinje length comes directly from the
 * arc-length bounds, so no separate line clipping is needed.
 */
public final class FissurePartitioner {

    /** Anatomical subsection labels, in order, fixed by the required output table layout. */
    public static final String[] LOBULE_LABELS = {
            "2Cb", "3Cb", "4/5Cb", "6Cb", "7Cb", "8Cb", "9Cb", "10Cb"
    };

    private FissurePartitioner() {
    }

    public static PartitionSet partition(LayerSet layers) {
        List<PolygonRoi> rawFissures = layers.getFissures();
        if (rawFissures.size() != 7) {
            throw new IllegalStateException(
                    "FissurePartitioner requires exactly 7 fissures (validated upstream); got " + rawFissures.size());
        }

        Roi cerebellum = layers.getCerebellum();
        PolygonRoi purkinje = layers.getPurkinje();
        Point2D.Double[] purkPoints = GeometryUtils.extractPoints(purkinje);
        double[] purkCumulative = GeometryUtils.cumulativeLengths(purkPoints);
        double purkTotalLength = purkCumulative[purkCumulative.length - 1];

        // --- Pass 1: orient each fissure pial -> Purkinje, and find where it attaches. ---
        List<OrientedFissure> oriented = new ArrayList<>(7);
        for (PolygonRoi fissure : rawFissures) {
            Point2D.Double[] raw = GeometryUtils.extractPoints(fissure);
            GeometryUtils.Projection projFirst = GeometryUtils.project(purkPoints, purkCumulative, raw[0]);
            GeometryUtils.Projection projLast =
                    GeometryUtils.project(purkPoints, purkCumulative, raw[raw.length - 1]);
            Point2D.Double[] pts;
            double innerArc;
            if (projFirst.distance < projLast.distance) {
                // raw[0] is closer to the Purkinje line than raw[last] -- the user traced
                // this one inner-to-outer, so flip it to match the pial -> Purkinje convention.
                pts = reversed(raw);
                innerArc = projFirst.arcLength;
            } else {
                pts = raw;
                innerArc = projLast.arcLength;
            }
            oriented.add(new OrientedFissure(pts, innerArc));
        }
        oriented.sort((a, b) -> Double.compare(a.innerArc, b.innerArc));

        // --- Pass 2: extend each (now-ordered) fissure and cut the cerebellum with it. ---
        ShapeRoi cerebellumShape = BooleanROIProcessor.copy(cerebellum);
        Rectangle bounds = cerebellum.getBounds();
        double extensionDistance = GeometryUtils.diagonal(bounds) * 4.0;

        // White matter centroid: the anatomical "center" toward which all fissures converge.
        // Computed once and reused for every fissure's inward extension.
        Point2D.Double wmCentroid = GeometryUtils.centroid(layers.getWhiteMatter());

        int n = oriented.size();
        double[] attachArc = new double[n];
        ShapeRoi[] sideHigh = new ShapeRoi[n]; // region of the cerebellum beyond fissure i (toward lobule 10)
        List<PolygonRoi> extendedCutLines = new ArrayList<>(n);

        for (int i = 0; i < n; i++) {
            OrientedFissure f = oriented.get(i);
            attachArc[i] = f.innerArc;

            Point2D.Double outer = f.points[0];
            Point2D.Double inner = f.points[f.points.length - 1];

            // OUTWARD extension (past pial surface): continue in the fissure's own
            // direction away from the cerebellum. This just needs to clear the bounding
            // box and does not affect anatomical accuracy.
            Point2D.Double outwardDir = GeometryUtils.normalize(GeometryUtils.subtract(outer, inner));
            Point2D.Double extendedNear = GeometryUtils.add(outer,
                    GeometryUtils.scale(outwardDir, extensionDistance));

            // INWARD extension (past Purkinje line, through granular layer toward WM):
            // aim at the white matter centroid rather than continuing the fissure's own
            // slope. The fissure's traced angle is arbitrary (it depends on which fold the
            // user traced through); the WM centroid is the anatomically correct target.
            Point2D.Double inwardDir = GeometryUtils.normalize(
                    GeometryUtils.subtract(wmCentroid, inner));
            Point2D.Double extendedFar = GeometryUtils.add(inner,
                    GeometryUtils.scale(inwardDir, extensionDistance));

            Point2D.Double[] cutLinePts = new Point2D.Double[f.points.length + 2];
            cutLinePts[0] = extendedNear;
            System.arraycopy(f.points, 0, cutLinePts, 1, f.points.length);
            cutLinePts[cutLinePts.length - 1] = extendedFar;
            extendedCutLines.add(toPolygonRoi(cutLinePts, Roi.POLYLINE));

            // Half-plane perpendicular is relative to the INWARD direction, which determines
            // how the granular layer and white matter are partitioned. The perpendicular to
            // the outward direction (fissure slope) is irrelevant below the Purkinje line.
            Point2D.Double perp = GeometryUtils.perpendicular(inwardDir);

            // Which perpendicular sign points toward lobule 10?
            // Test against a point slightly further along the Purkinje line than this
            // fissure's attachment. Reference point is `inner` (the Purkinje attachment),
            // axis is `inwardDir` (the cut direction past the Purkinje line).
            double sampleArc = Math.min(purkTotalLength, f.innerArc + Math.max(1.0, purkTotalLength * 0.01));
            Point2D.Double samplePoint = GeometryUtils.pointAtArcLength(purkPoints, purkCumulative, sampleArc);
            double side = cross(inwardDir, GeometryUtils.subtract(samplePoint, inner));
            double sign = side >= 0 ? 1.0 : -1.0;
            Point2D.Double signedPerp = GeometryUtils.scale(perp, sign);

            Point2D.Double cap1 = GeometryUtils.add(extendedFar, GeometryUtils.scale(signedPerp, extensionDistance));
            Point2D.Double cap2 = GeometryUtils.add(extendedNear, GeometryUtils.scale(signedPerp, extensionDistance));

            Point2D.Double[] halfPlanePts = new Point2D.Double[f.points.length + 4];
            halfPlanePts[0] = extendedNear;
            System.arraycopy(f.points, 0, halfPlanePts, 1, f.points.length);
            halfPlanePts[f.points.length + 1] = extendedFar;
            halfPlanePts[f.points.length + 2] = cap1;
            halfPlanePts[f.points.length + 3] = cap2;

            ShapeRoi halfPlaneShape = new ShapeRoi(toPolygonRoi(halfPlanePts, Roi.POLYGON));
            sideHigh[i] = BooleanROIProcessor.and(cerebellumShape, halfPlaneShape);
        }

        // --- Assemble the 8 partitions from consecutive differences of the half-planes. ---
        List<PartitionSet.Partition> partitions = new ArrayList<>(8);
        partitions.add(new PartitionSet.Partition(
                LOBULE_LABELS[0],
                BooleanROIProcessor.subtract(cerebellumShape, sideHigh[0]),
                0.0, attachArc[0]));
        for (int k = 1; k <= 6; k++) {
            partitions.add(new PartitionSet.Partition(
                    LOBULE_LABELS[k],
                    BooleanROIProcessor.subtract(sideHigh[k - 1], sideHigh[k]),
                    attachArc[k - 1], attachArc[k]));
        }
        partitions.add(new PartitionSet.Partition(
                LOBULE_LABELS[7],
                sideHigh[6],
                attachArc[6], purkTotalLength));

        return new PartitionSet(partitions, extendedCutLines);
    }

    private static final class OrientedFissure {
        final Point2D.Double[] points; // index 0 = pial/outer end, last index = Purkinje/inner end
        final double innerArc;

        OrientedFissure(Point2D.Double[] points, double innerArc) {
            this.points = points;
            this.innerArc = innerArc;
        }
    }

    private static Point2D.Double[] reversed(Point2D.Double[] arr) {
        Point2D.Double[] rev = new Point2D.Double[arr.length];
        for (int i = 0; i < arr.length; i++) {
            rev[i] = arr[arr.length - 1 - i];
        }
        return rev;
    }

    private static double cross(Point2D.Double a, Point2D.Double b) {
        return a.x * b.y - a.y * b.x;
    }

    private static PolygonRoi toPolygonRoi(Point2D.Double[] pts, int type) {
        int n = pts.length;
        float[] xs = new float[n];
        float[] ys = new float[n];
        for (int i = 0; i < n; i++) {
            xs[i] = (float) pts[i].x;
            ys[i] = (float) pts[i].y;
        }
        return new PolygonRoi(xs, ys, n, type);
    }
}
