package org.cerebellum.morphometry.geometry;

import ij.IJ;
import ij.gui.PolygonRoi;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import org.cerebellum.morphometry.model.LayerSet;
import org.cerebellum.morphometry.model.PartitionSet;

import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Partitions the cerebellum into {@code N+1} lobule regions from {@code N} traced fissures
 * (standard case: 7 fissures &rarr; 8 lobules, but any count is supported &mdash; see {@link
 * #buildLobuleLabels}) using a <b>subtract-and-split</b> strategy (equivalent to the ROI
 * Manager's XOR&thinsp;+&thinsp;Split), applied <b>separately to the Molecular and Granular
 * layers</b>, with an <b>adaptive strip-width search</b> to make each split robust.
 *
 * <h2>Four things went wrong before landing on this design</h2>
 * <ol>
 *   <li><b>Half-planes.</b> Needing to know which side of a cut is "toward the last lobule"
 *       was estimated with a cross-product sign test, which is unreliable exactly where
 *       several cuts cross close together.</li>
 *   <li><b>Extending cuts across the solid Cerebellum outline.</b> The Cerebellum ROI has
 *       no White-Matter-shaped hole, so a cut that only reaches the granular layer leaves
 *       everything connected underneath through the un-cut white matter core. Extending
 *       cuts all the way through that core "to be safe" instead let a straight line
 *       re-emerge through the pial surface at some unrelated point, carving a second,
 *       unwanted cut through neighbouring tissue.</li>
 *   <li><b>One long cut spanning both layers with a single fixed strip width.</b> Even
 *       after fixing the topology by partitioning Grey Matter (which does have a
 *       White-Matter hole), a single strip width picked as a fixed fraction of the whole
 *       image diagonal turned out to sit in an unreliable zone: Java2D's {@code Area}
 *       silently fragmented cuts into spurious extra pieces when the strip was too thin
 *       relative to the local vertex spacing of the boundary it crossed, but a strip wide
 *       enough to be safe in one region was wide enough to merge neighbouring cuts
 *       together in another. No single fixed width could be shown to be safe for
 *       arbitrary real input, because the safe window's location depends on how finely
 *       the user traced their ROIs and on the local anatomy scale &mdash; neither of
 *       which is known in advance.</li>
 *   <li><b>Assuming fissures stop exactly at the Purkinje line.</b> Real traced fissures
 *       turned out to run the <em>full</em> pial-surface-to-white-matter depth (easier to
 *       trace than stopping precisely at a specific cell layer), not pial-to-Purkinje as
 *       earlier versions required. Splitting each fissure at its own endpoints then
 *       produced cuts that vastly overshot the molecular layer and barely existed at all
 *       in the granular layer, since the "Purkinje end" the code expected wasn't there.
 *       The fix is to stop requiring an exact stopping point at all: find where each
 *       fissure's own path comes closest to the Purkinje line, and use that as the natural
 *       split between its molecular and granular portions (see below).</li>
 * </ol>
 *
 * <h2>This design</h2>
 * <ol>
 *   <li><b>Orient</b> each fissure pial&rarr;white-matter by checking which endpoint is
 *       nearer the Cerebellum outline, then <b>find where it crosses the Purkinje line</b>
 *       by sampling finely along its own traced path. That crossing point's arc-length
 *       position along Purkinje sorts the fissures into anatomical order; its position
 *       along the fissure's own path splits that fissure into a molecular portion (pial
 *       end&rarr;crossing) and a granular portion (crossing&rarr;WM end).</li>
 *   <li><b>Partition the Molecular layer</b> ({@code Cerebellum \ GranularWM} &mdash; an
 *       algebraically equivalent, single-subtraction way to get the same shape as
 *       Grey&nbsp;\&nbsp;Granular) using each fissure's molecular portion, extended a small
 *       distance past its two ends to absorb ordinary mismatch between the fissure, the
 *       pial outline, and the Granular+WM outline. No direction is extrapolated beyond
 *       what the user's own trace already establishes.</li>
 *   <li><b>Partition the Granular layer</b> ({@code GranularWM \ WhiteMatter}) the same
 *       way, using each fissure's granular portion (crossing&rarr;WM end).</li>
 *   <li><b>For each stage independently</b>, try a small set of strip widths (as
 *       fractions of that stage's own local cut length, thinnest first) and keep the
 *       first one that yields the expected N+1 topologically-clean pieces covering most of
 *       the stage's area. In practice the thinnest candidate almost always succeeds once
 *       the width comparison is made against realistically-spaced boundary vertices; the
 *       other candidates exist only as a fallback for unusually dense tracing.</li>
 *   <li><b>Combine</b> each lobule's Molecular piece and Granular piece into one region
 *       (their union). {@link org.cerebellum.morphometry.geometry.PartitionClipper}
 *       intersects this with Granular/Molecular separately downstream, so the union is
 *       measurement-neutral &mdash; it just carries both pieces together.</li>
 * </ol>
 */
public final class FissurePartitioner {

    /**
     * Anatomical subsection labels for the standard rodent vermis scheme (2Cb nearest the
     * Purkinje start), used when there are exactly 7 fissures. See {@link #buildLobuleLabels}.
     */
    private static final String[] STANDARD_LOBULE_LABELS = {
            "2Cb", "3Cb", "4/5Cb", "6Cb", "7Cb", "8Cb", "9Cb", "10Cb"
    };

    /**
     * Builds subsection labels for {@code fissureCount} fissures, which produce {@code
     * fissureCount + 1} subsections. Ten lobules across 7 fissures (2Cb, 3Cb, 4/5Cb, 6Cb,
     * 7Cb, 8Cb, 9Cb, 10Cb — lobule 1 is conventionally fused/not separately measured) is the
     * standard scheme for a midline sagittal section of rodent vermis, but it isn't
     * universal: off-midline sagittal cuts, coronal or horizontal sections, damaged tissue,
     * and other species all have a different lobule count or don't follow this numbering at
     * all. Rather than assume the standard scheme always applies, this only uses the named
     * labels when the fissure count actually matches it (7); any other count gets generic
     * "Section N" labels instead, since a specific anatomical name would be a guess.
     */
    private static String[] buildLobuleLabels(int fissureCount) {
        return labelsForSubsectionCount(fissureCount + 1);
    }

    /**
     * Labels for {@code count} subsections, however they arose &mdash; from fissures within one
     * traced piece, or (see {@link org.cerebellum.morphometry.measurement.MeasurementEngine#combine})
     * from several separately-traced pieces of one cerebellum pooled together. Uses the standard
     * rodent vermis names when the count matches that scheme exactly, and generic "Section N"
     * names otherwise, since a specific anatomical name would then be a guess.
     */
    public static String[] labelsForSubsectionCount(int count) {
        if (count == STANDARD_LOBULE_LABELS.length) {
            return STANDARD_LOBULE_LABELS;
        }
        String[] labels = new String[count];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = "Section " + (i + 1);
        }
        return labels;
    }

    /**
     * Candidate strip half-widths to try, each expressed as a fraction of the current
     * stage's own average local cut length. Tried thinnest-first; the first one that
     * yields exactly N+1 valid pieces (N = number of fissures) covering most of the
     * stage's area is used. Three
     * candidates spanning a wide range are enough in practice — Java2D's {@code Area}
     * turned out to be robust across a wide width range once strips are compared against
     * a boundary with realistic (not pathologically dense) vertex spacing, so this exists
     * as a safety net for unusually dense tracing rather than as the primary mechanism.
     */
    private static final double[] WIDTH_FRACTION_CANDIDATES = {0.02, 0.06, 0.15};
    private static final double MIN_ABS_HALF_WIDTH_PX = 1.0;

    /** A width candidate is accepted only if the surviving pieces retain at least this much of the stage's area. */
    private static final double MIN_ACCEPTABLE_COVERAGE = 0.75;

    /** Small overshoot (as a fraction of the cut sub-path's own length) added past each end
     * of a fissure's molecular/granular portion, to guarantee a clean crossing despite
     * ordinary hand-tracing mismatch between the fissure and the layer boundary it needs
     * to fully cross (e.g. the fissure's WM-adjacent end not landing exactly on the White
     * Matter outline). */
    private static final double ENDPOINT_OVERSHOOT_FRACTION = 0.25;
    private static final double MIN_ABS_OVERSHOOT_PX = 8.0;

    /** Pieces smaller than this fraction of the stage's own base-shape area are treated as artifacts. */
    private static final double MIN_PIECE_AREA_FRACTION = 0.005; // 0.5%

    private FissurePartitioner() {
    }

    public static PartitionSet partition(LayerSet layers) {
        List<PolygonRoi> rawFissures = layers.getFissures();
        if (rawFissures.isEmpty()) {
            throw new IllegalStateException(
                    "FissurePartitioner requires at least 1 fissure (validated upstream); got 0");
        }

        PolygonRoi purkinje = layers.getPurkinje();
        Point2D.Double[] purkPoints     = GeometryUtils.extractPoints(purkinje);
        double[]         purkCumulative = GeometryUtils.cumulativeLengths(purkPoints);
        double           purkTotalLength = purkCumulative[purkCumulative.length - 1];
        Point2D.Double[] cerebellumBoundary = GeometryUtils.extractPoints(layers.getCerebellum());

        // -----------------------------------------------------------------------
        // Orient each fissure pial→WM (fissures are traced across the full tissue depth,
        // not stopped exactly at the Purkinje line — see class javadoc), then find where
        // each one crosses the Purkinje line. That crossing point splits the fissure into
        // its molecular portion (pial end→crossing) and granular portion (crossing→WM
        // end), and its arc-length position along Purkinje gives the 2Cb→10Cb order.
        // -----------------------------------------------------------------------
        List<OrientedFissure> oriented = new ArrayList<>(rawFissures.size());
        for (PolygonRoi fissure : rawFissures) {
            Point2D.Double[] raw = GeometryUtils.extractPoints(fissure);
            double d0    = GeometryUtils.nearestPointOnPolygon(cerebellumBoundary, raw[0], true).distance(raw[0]);
            double dLast = GeometryUtils.nearestPointOnPolygon(cerebellumBoundary, raw[raw.length - 1], true)
                    .distance(raw[raw.length - 1]);
            Point2D.Double[] pts = (d0 <= dLast) ? raw : reversed(raw);

            Crossing crossing = findPurkinjeCrossing(pts, purkPoints, purkCumulative);
            oriented.add(new OrientedFissure(pts, crossing));
        }
        oriented.sort(Comparator.comparingDouble(f -> f.crossing.purkinjeArc));

        int      n         = oriented.size(); // however many fissures were traced
        double[] attachArc = new double[n];
        for (int i = 0; i < n; i++) {
            attachArc[i] = oriented.get(i).crossing.purkinjeArc;
        }

        // -----------------------------------------------------------------------
        // Split each fissure into its molecular and granular portions using EACH LAYER'S
        // OWN BOUNDARY, not the Purkinje line.
        //
        // This matters: a layer's ring can only be severed by a cut that spans the ring's
        // full width, i.e. from outside its outer edge to inside its inner edge. The
        // molecular ring's inner edge is the Granular+WM outline; the granular ring's outer
        // edge is that same outline and its inner edge is White Matter. The Purkinje line is
        // NOT either of those — it's a separate hand-traced curve that in real tracings sits
        // some distance off the Granular+WM boundary (on real data, tens of pixels out into
        // molecular territory). Ending the molecular cut at the Purkinje line therefore left
        // it short of the molecular ring's inner edge, so it failed to sever the ring at all
        // and the whole molecular layer came back as one undivided piece. Using the layer's
        // own boundary makes each cut span exactly the ring it has to cut, no matter where
        // the user happened to draw the Purkinje line. The Purkinje crossing is still used —
        // but only for ORDERING the fissures, which is what it's actually good for.
        // -----------------------------------------------------------------------
        Roi granularWMRoi = layers.getGranularWM();
        Roi whiteMatterRoi = layers.getWhiteMatter();

        ShapeRoi molecularBase = BooleanROIProcessor.subtract(layers.getCerebellum(), granularWMRoi);
        ShapeRoi granularBase  = BooleanROIProcessor.subtract(granularWMRoi, whiteMatterRoi);

        List<Segment> molecularCuts = new ArrayList<>(n);
        List<Segment> granularCuts  = new ArrayList<>(n);
        for (OrientedFissure f : oriented) {
            double[] cum = GeometryUtils.cumulativeLengths(f.points);

            // Where the fissure first enters Granular+WM, and where it first enters White
            // Matter, walking from the pial end inwards. These are the two layer boundaries
            // the fissure crosses; they delimit each layer's portion of it.
            double arcAtGranular = firstArcInside(f.points, cum, granularWMRoi);
            double arcAtWM       = firstArcInside(f.points, cum, whiteMatterRoi);

            // Fallbacks keep this working for degenerate tracings: if the fissure never
            // reaches Granular+WM, fall back to its Purkinje crossing (old behaviour); if it
            // never reaches White Matter, run the granular cut out to the fissure's own end.
            if (Double.isNaN(arcAtGranular)) {
                arcAtGranular = f.crossing.pathArc;
            }
            if (Double.isNaN(arcAtWM) || arcAtWM <= arcAtGranular) {
                arcAtWM = cum[cum.length - 1];
            }

            Point2D.Double pAtGranular = GeometryUtils.pointAtArcLength(f.points, cum, arcAtGranular);
            Point2D.Double pAtWM       = GeometryUtils.pointAtArcLength(f.points, cum, arcAtWM);

            molecularCuts.add(extendedSegment(pathBefore(f.points, cum, arcAtGranular, pAtGranular)));
            granularCuts.add(extendedSegment(
                    subPath(f.points, cum, arcAtGranular, pAtGranular, arcAtWM, pAtWM)));
        }

        List<ArcPiece> molecularPieces =
                partitionRing(molecularBase, molecularCuts, purkPoints, purkCumulative, "molecular layer");
        List<ArcPiece> granularPieces =
                partitionRing(granularBase, granularCuts, purkPoints, purkCumulative, "granular layer");

        // -----------------------------------------------------------------------
        // Combine: pieces from the two layers are paired by their sorted position along the
        // Purkinje line. Both stages cut the same fissures across the same tissue, so once
        // each has produced its expected number of pieces they correspond one-to-one in that
        // order. (A previous version mapped pieces onto fixed "nominal slots" derived from
        // the fissure arc positions; that silently broke for ring-shaped layers, where N cuts
        // produce N pieces rather than N+1 and one piece spans the seam, so the slots didn't
        // line up with anything real.)
        // -----------------------------------------------------------------------
        int count = Math.min(molecularPieces.size(), granularPieces.size());
        if (molecularPieces.size() != granularPieces.size()) {
            IJ.log("[Cerebellar Morphometry] Warning: the molecular layer split into "
                    + molecularPieces.size() + " section(s) but the granular layer split into "
                    + granularPieces.size() + ". They should match. Using the first " + count
                    + ". Check that every fissure runs cleanly from the pial surface, through the "
                    + "Granular+WM boundary, and into White Matter.");
        }

        String[] labels = FissurePartitioner.labelsForSubsectionCount(count);
        List<PartitionSet.Partition> partitions = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            ShapeRoi mol  = molecularPieces.get(i).shape;
            ShapeRoi gran = granularPieces.get(i).shape;
            ShapeRoi combined = new ShapeRoi(mol).or(new ShapeRoi(gran));

            // Purkinje span for this section: from this piece's start to the next piece's start.
            double arcStart = molecularPieces.get(i).arcLength;
            double arcEnd   = (i + 1 < count) ? molecularPieces.get(i + 1).arcLength : purkTotalLength;
            partitions.add(new PartitionSet.Partition(labels[i], combined, arcStart, arcEnd));
        }

        // Overlay cut-lines: each fissure's own traced path already spans pial→WM.
        List<PolygonRoi> overlayLines = new ArrayList<>(n);
        for (OrientedFissure f : oriented) {
            overlayLines.add(toPolygonRoi(f.points, Roi.POLYLINE));
        }

        return new PartitionSet(partitions, overlayLines);
    }

    // -----------------------------------------------------------------------
    // Core: subtract-and-split one "ring" shape with an adaptive strip-width search.
    // -----------------------------------------------------------------------

    /** One split piece, with where its centroid falls along the Purkinje line (used for ordering). */
    private static final class ArcPiece {
        final ShapeRoi shape;
        final double arcLength;

        ArcPiece(ShapeRoi shape, double arcLength) {
            this.shape = shape;
            this.arcLength = arcLength;
        }
    }

    /**
     * Subtracts thin strips built from {@code cuts} out of {@code baseShape} and splits the
     * result, trying increasingly wide strips until one yields the expected number of pieces
     * covering most of {@code baseShape}'s area. Returns the pieces ordered by where their
     * centroid falls along the Purkinje line.
     *
     * <p><b>How many pieces to expect depends on the shape's topology.</b> An open ribbon is
     * cut into {@code N+1} pieces by {@code N} cuts, but a closed ring (an annulus — a shape
     * with a hole in it) is cut into only {@code N}: the first cut merely opens the ring into
     * a ribbon without separating anything. Cerebellar layers are normally rings, since the
     * layer wraps all the way around the white matter core; they're only ribbons when the
     * ring has been deliberately pinched open at the peduncle (see the README's "Closing the
     * loop"). This is detected here from the mask itself rather than assumed, because getting
     * it wrong made a perfectly good split look like a failure — the code would demand N+1,
     * never get it, fall back to a bad attempt, and mislabel the results.</p>
     *
     * <p>Works on a rasterized pixel mask with 8-connected flood-fill labeling, not on
     * {@code ShapeRoi}/{@code Area} directly — see {@link RasterSplitUtils} for why.</p>
     */
    private static List<ArcPiece> partitionRing(ShapeRoi baseShape, List<Segment> cuts,
            Point2D.Double[] purkPoints, double[] purkCumulative, String stageName) {

        Rectangle bounds = baseShape.getBounds();
        int margin = (int) Math.max(50, 0.08 * Math.max(bounds.width, bounds.height));
        Rectangle canvas = new Rectangle(bounds.x - margin, bounds.y - margin,
                bounds.width + 2 * margin, bounds.height + 2 * margin);
        int w = canvas.width, h = canvas.height;

        boolean[] baseMask = RasterSplitUtils.rasterize(baseShape, canvas);
        long baseArea = countTrue(baseMask);
        long minPieceArea = (long) (baseArea * MIN_PIECE_AREA_FRACTION);

        boolean isRing = hasHole(baseMask, w, h);
        int expected = cuts.size() + (isRing ? 0 : 1);
        IJ.log("[Cerebellar Morphometry] " + stageName + " is "
                + (isRing ? "a closed ring, so " + cuts.size() + " fissure(s) split it into "
                          : "an open ribbon, so " + cuts.size() + " fissure(s) split it into ")
                + expected + " section(s).");

        double avgLen = 0;
        for (Segment s : cuts) {
            avgLen += s.refLength;
        }
        avgLen /= cuts.size();

        List<RasterSplitUtils.Component> bestFiltered = null;
        long   bestArea = -1;
        int    bestDiff = Integer.MAX_VALUE;

        for (double frac : WIDTH_FRACTION_CANDIDATES) {
            double halfWidth = Math.max(MIN_ABS_HALF_WIDTH_PX, avgLen * frac);

            boolean[] stripsMask = new boolean[w * h];
            for (Segment s : cuts) {
                Point2D.Double[] stripPts = GeometryUtils.polylineStrip(s.pts, halfWidth);
                Roi stripRoi = toPolygonRoi(stripPts, Roi.POLYGON);
                RasterSplitUtils.orInPlace(stripsMask, RasterSplitUtils.rasterize(stripRoi, canvas));
            }

            boolean[] divided = baseMask.clone();
            RasterSplitUtils.subtractInPlace(divided, stripsMask);

            List<RasterSplitUtils.Component> raw = RasterSplitUtils.connectedComponents(divided, w, h);
            List<RasterSplitUtils.Component> filtered = new ArrayList<>();
            long filteredArea = 0;
            for (RasterSplitUtils.Component c : raw) {
                if (c.size() >= minPieceArea) {
                    filtered.add(c);
                    filteredArea += c.size();
                }
            }

            boolean countOk    = filtered.size() == expected;
            boolean coverageOk = filteredArea >= baseArea * MIN_ACCEPTABLE_COVERAGE;
            if (countOk && coverageOk) {
                return traceAndSort(filtered, canvas, w, h, purkPoints, purkCumulative);
            }

            int diff = Math.abs(filtered.size() - expected);
            if (diff < bestDiff || (diff == bestDiff && filteredArea > bestArea)) {
                bestDiff     = diff;
                bestArea     = filteredArea;
                bestFiltered = filtered;
            }
        }

        IJ.log("[Cerebellar Morphometry] Warning: could not find a strip width that cleanly splits the "
                + stageName + " into " + expected + " pieces after trying " + WIDTH_FRACTION_CANDIDATES.length
                + " candidate widths. Using the closest attempt (" + (bestFiltered == null ? 0 : bestFiltered.size())
                + " pieces). Consider retracing the fissures or layer boundaries with smoother lines.");
        return traceAndSort(bestFiltered == null ? new ArrayList<>() : bestFiltered, canvas, w, h,
                purkPoints, purkCumulative);
    }

    private static long countTrue(boolean[] mask) {
        long n = 0;
        for (boolean b : mask) {
            if (b) {
                n++;
            }
        }
        return n;
    }

    /**
     * Traces each accepted component's outline into a {@link ShapeRoi} (absolute image
     * coordinates) and returns them ordered by where their centroid falls along the Purkinje
     * line. Tracing only happens here, for the winning candidate — not during the width search.
     */
    private static List<ArcPiece> traceAndSort(List<RasterSplitUtils.Component> components, Rectangle canvas,
            int w, int h, Point2D.Double[] purkPoints, double[] purkCumulative) {
        List<ArcPiece> result = new ArrayList<>(components.size());
        for (RasterSplitUtils.Component c : components) {
            Point2D.Double centroid = new Point2D.Double(c.centroidX() + canvas.x, c.centroidY() + canvas.y);
            GeometryUtils.Projection proj = GeometryUtils.project(purkPoints, purkCumulative, centroid);
            Roi traced = RasterSplitUtils.traceComponent(c, w, h, canvas);
            result.add(new ArcPiece(new ShapeRoi(traced), proj.arcLength));
        }
        result.sort(Comparator.comparingDouble(p -> p.arcLength));
        return result;
    }

    /**
     * True when {@code mask}'s foreground encloses at least one hole — i.e. it's a ring
     * (annulus), not a simply-connected blob. Found by flood-filling the background inwards
     * from the canvas border: any background left unreached is enclosed by foreground.
     */
    private static boolean hasHole(boolean[] mask, int w, int h) {
        boolean[] reached = new boolean[mask.length];
        java.util.ArrayDeque<Integer> queue = new java.util.ArrayDeque<>();
        for (int x = 0; x < w; x++) {
            queue.add(x);
            queue.add((h - 1) * w + x);
        }
        for (int y = 0; y < h; y++) {
            queue.add(y * w);
            queue.add(y * w + (w - 1));
        }
        while (!queue.isEmpty()) {
            int i = queue.poll();
            if (i < 0 || i >= mask.length || reached[i] || mask[i]) {
                continue;
            }
            reached[i] = true;
            int x = i % w, y = i / w;
            if (x > 0)     queue.add(i - 1);
            if (x < w - 1) queue.add(i + 1);
            if (y > 0)     queue.add(i - w);
            if (y < h - 1) queue.add(i + w);
        }
        // Any background pixel the border flood couldn't reach is inside a hole. Require a
        // few of them so a stray one-pixel rasterization artifact isn't mistaken for a hole.
        int enclosed = 0;
        for (int i = 0; i < mask.length; i++) {
            if (!mask[i] && !reached[i] && ++enclosed > 32) {
                return true;
            }
        }
        return false;
    }

    // -----------------------------------------------------------------------
    // Inner types
    // -----------------------------------------------------------------------

    private static final class OrientedFissure {
        final Point2D.Double[] points; // index 0 = pial end, last = WM end
        final Crossing crossing;       // where this fissure crosses the Purkinje line

        OrientedFissure(Point2D.Double[] points, Crossing crossing) {
            this.points   = points;
            this.crossing = crossing;
        }
    }

    /** Where a fissure's own path crosses the Purkinje line. */
    private static final class Crossing {
        final Point2D.Double point;
        final double pathArc;     // arc-length along the fissure's own path
        final double purkinjeArc; // arc-length along the Purkinje polyline

        Crossing(Point2D.Double point, double pathArc, double purkinjeArc) {
            this.point       = point;
            this.pathArc     = pathArc;
            this.purkinjeArc = purkinjeArc;
        }
    }

    private static final class Segment {
        final Point2D.Double[] pts; // cut polyline, already extended past both true endpoints
        /** True local layer thickness (before overshoot padding) — used to scale strip width. */
        final double refLength;

        Segment(Point2D.Double[] pts, double refLength) {
            this.pts = pts;
            this.refLength = refLength;
        }
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Arc-length along {@code pts} at which the path first enters {@code region}, walking from
     * the pial end inwards; {@code NaN} if it never does. This is how each layer's portion of a
     * fissure is delimited by that layer's OWN boundary, rather than by the Purkinje line —
     * see the long comment in {@link #partition} for why that distinction matters.
     */
    private static double firstArcInside(Point2D.Double[] pts, double[] cum, Roi region) {
        if (region == null) {
            return Double.NaN;
        }
        double total = cum[cum.length - 1];
        int samples = (int) Math.max(50, Math.min(600, total));
        for (int i = 0; i <= samples; i++) {
            double arc = total * i / samples;
            Point2D.Double p = GeometryUtils.pointAtArcLength(pts, cum, arc);
            if (region.contains((int) Math.round(p.x), (int) Math.round(p.y))) {
                return arc;
            }
        }
        return Double.NaN;
    }

    /** The portion of {@code pts} between two arc positions, with exact endpoints at each. */
    private static Point2D.Double[] subPath(Point2D.Double[] pts, double[] cum,
            double startArc, Point2D.Double startPoint, double endArc, Point2D.Double endPoint) {
        List<Point2D.Double> result = new ArrayList<>();
        result.add(startPoint);
        for (int i = 0; i < pts.length; i++) {
            if (cum[i] > startArc && cum[i] < endArc) {
                result.add(pts[i]);
            }
        }
        result.add(endPoint);
        return result.toArray(new Point2D.Double[0]);
    }

    /**
     * Finds where {@code fissurePts} (a short pial-to-WM traced path) comes closest to the
     * Purkinje polyline, by sampling finely along the fissure's own path. This is the point
     * used both to split the fissure into its molecular and granular portions, and (via its
     * Purkinje arc-length) to order lobules 2Cb→10Cb.
     */
    private static Crossing findPurkinjeCrossing(Point2D.Double[] fissurePts, Point2D.Double[] purkPts, double[] purkCumulative) {
        double[] fissureCum = GeometryUtils.cumulativeLengths(fissurePts);
        double totalLen = fissureCum[fissureCum.length - 1];
        int samples = (int) Math.max(20, Math.min(300, totalLen));

        double bestDist = Double.POSITIVE_INFINITY;
        Point2D.Double bestPoint = fissurePts[0];
        double bestPathArc = 0;
        double bestPurkArc = 0;
        for (int i = 0; i <= samples; i++) {
            double arc = totalLen * i / samples;
            Point2D.Double p = GeometryUtils.pointAtArcLength(fissurePts, fissureCum, arc);
            GeometryUtils.Projection proj = GeometryUtils.project(purkPts, purkCumulative, p);
            if (proj.distance < bestDist) {
                bestDist    = proj.distance;
                bestPoint   = p;
                bestPathArc = arc;
                bestPurkArc = proj.arcLength;
            }
        }
        return new Crossing(bestPoint, bestPathArc, bestPurkArc);
    }

    /** The portion of {@code pts} from its start up to {@code splitArc}, ending exactly at {@code splitPoint}. */
    private static Point2D.Double[] pathBefore(Point2D.Double[] pts, double[] cum, double splitArc, Point2D.Double splitPoint) {
        List<Point2D.Double> result = new ArrayList<>();
        for (int i = 0; i < pts.length; i++) {
            if (cum[i] < splitArc) {
                result.add(pts[i]);
            } else {
                break;
            }
        }
        if (result.isEmpty()) {
            result.add(pts[0]); // degenerate fallback: split point landed exactly on the first vertex
        }
        result.add(splitPoint);
        return result.toArray(new Point2D.Double[0]);
    }

    /** The portion of {@code pts} from {@code splitPoint} onward to its end. */
    private static Point2D.Double[] pathAfter(Point2D.Double[] pts, double[] cum, double splitArc, Point2D.Double splitPoint) {
        List<Point2D.Double> result = new ArrayList<>();
        result.add(splitPoint);
        for (int i = 0; i < pts.length; i++) {
            if (cum[i] > splitArc) {
                result.add(pts[i]);
            }
        }
        if (result.size() < 2) {
            result.add(pts[pts.length - 1]); // degenerate fallback: split point landed exactly on the last vertex
        }
        return result.toArray(new Point2D.Double[0]);
    }

    /**
     * Builds a cut {@link Segment} from a traced sub-path by extending its two end segments
     * a small distance past their true endpoints — enough to absorb ordinary mismatch between
     * this path and the layer boundary it needs to fully cross, without extrapolating any
     * direction that wasn't already in the user's own trace.
     */
    private static Segment extendedSegment(Point2D.Double[] path) {
        double refLength = pathLength(path);
        double overshoot = Math.max(MIN_ABS_OVERSHOOT_PX, refLength * ENDPOINT_OVERSHOOT_FRACTION);

        Point2D.Double startDir = GeometryUtils.normalize(GeometryUtils.subtract(path[0], path[1]));
        Point2D.Double endDir   = GeometryUtils.normalize(GeometryUtils.subtract(path[path.length - 1], path[path.length - 2]));
        Point2D.Double newStart = GeometryUtils.add(path[0], GeometryUtils.scale(startDir, overshoot));
        Point2D.Double newEnd   = GeometryUtils.add(path[path.length - 1], GeometryUtils.scale(endDir, overshoot));

        Point2D.Double[] extended = new Point2D.Double[path.length];
        extended[0] = newStart;
        extended[path.length - 1] = newEnd;
        for (int i = 1; i < path.length - 1; i++) {
            extended[i] = path[i];
        }
        return new Segment(extended, refLength);
    }

    private static double pathLength(Point2D.Double[] pts) {
        double len = 0;
        for (int i = 1; i < pts.length; i++) {
            len += pts[i - 1].distance(pts[i]);
        }
        return len;
    }

    private static Point2D.Double[] reversed(Point2D.Double[] arr) {
        Point2D.Double[] rev = new Point2D.Double[arr.length];
        for (int i = 0; i < arr.length; i++) {
            rev[i] = arr[arr.length - 1 - i];
        }
        return rev;
    }

    private static PolygonRoi toPolygonRoi(Point2D.Double[] pts, int type) {
        int     n  = pts.length;
        float[] xs = new float[n];
        float[] ys = new float[n];
        for (int i = 0; i < n; i++) {
            xs[i] = (float) pts[i].x;
            ys[i] = (float) pts[i].y;
        }
        return new PolygonRoi(xs, ys, n, type);
    }
}
