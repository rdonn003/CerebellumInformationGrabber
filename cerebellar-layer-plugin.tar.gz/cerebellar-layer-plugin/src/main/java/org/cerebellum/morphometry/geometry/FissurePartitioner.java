package org.cerebellum.morphometry.geometry;

import ij.IJ;
import ij.gui.PolygonRoi;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import org.cerebellum.morphometry.model.LayerSet;
import org.cerebellum.morphometry.model.PartitionSet;

import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Partitions the cerebellum into {@code N+1} lobule regions from {@code N} traced fissures
 * (standard case: 7 fissures &rarr; 8 lobules, but any count is supported &mdash; see {@link
 * #buildLobuleLabels}) using a <b>subtract-and-split</b> strategy (equivalent to the ROI
 * Manager's XOR&thinsp;+&thinsp;Split), applied <b>separately to the Molecular and Granular
 * layers</b>, with an <b>adaptive strip-width search</b> to make each split robust.
 *
 * <h2>Four things went wrong before landing on this design</h2>
 * <ol>
 *   <li><b>Half-planes.</b> Needing to know which side of a cut is "toward the last lobule"
 *       was estimated with a cross-product sign test, which is unreliable exactly where
 *       several cuts cross close together.</li>
 *   <li><b>Extending cuts across the solid Cerebellum outline.</b> The Cerebellum ROI has
 *       no White-Matter-shaped hole, so a cut that only reaches the granular layer leaves
 *       everything connected underneath through the un-cut white matter core. Extending
 *       cuts all the way through that core "to be safe" instead let a straight line
 *       re-emerge through the pial surface at some unrelated point, carving a second,
 *       unwanted cut through neighbouring tissue.</li>
 *   <li><b>One long cut spanning both layers with a single fixed strip width.</b> Even
 *       after fixing the topology by partitioning Grey Matter (which does have a
 *       White-Matter hole), a single strip width picked as a fixed fraction of the whole
 *       image diagonal turned out to sit in an unreliable zone: Java2D's {@code Area}
 *       silently fragmented cuts into spurious extra pieces when the strip was too thin
 *       relative to the local vertex spacing of the boundary it crossed, but a strip wide
 *       enough to be safe in one region was wide enough to merge neighbouring cuts
 *       together in another. No single fixed width could be shown to be safe for
 *       arbitrary real input, because the safe window's location depends on how finely
 *       the user traced their ROIs and on the local anatomy scale &mdash; neither of
 *       which is known in advance.</li>
 *   <li><b>Assuming fissures stop exactly at the Purkinje line.</b> Real traced fissures
 *       turned out to run the <em>full</em> pial-surface-to-white-matter depth (easier to
 *       trace than stopping precisely at a specific cell layer), not pial-to-Purkinje as
 *       earlier versions required. Splitting each fissure at its own endpoints then
 *       produced cuts that vastly overshot the molecular layer and barely existed at all
 *       in the granular layer, since the "Purkinje end" the code expected wasn't there.
 *       The fix is to stop requiring an exact stopping point at all: find where each
 *       fissure's own path comes closest to the Purkinje line, and use that as the natural
 *       split between its molecular and granular portions (see below).</li>
 * </ol>
 *
 * <h2>This design</h2>
 * <ol>
 *   <li><b>Orient</b> each fissure pial&rarr;white-matter by checking which endpoint is
 *       nearer the Cerebellum outline, then <b>find where it crosses the Purkinje line</b>
 *       by sampling finely along its own traced path. That crossing point's arc-length
 *       position along Purkinje sorts the fissures into anatomical order; its position
 *       along the fissure's own path splits that fissure into a molecular portion (pial
 *       end&rarr;crossing) and a granular portion (crossing&rarr;WM end).</li>
 *   <li><b>Partition the Molecular layer</b> ({@code Cerebellum \ GranularWM} &mdash; an
 *       algebraically equivalent, single-subtraction way to get the same shape as
 *       Grey&nbsp;\&nbsp;Granular) using each fissure's molecular portion, extended a small
 *       distance past its two ends to absorb ordinary mismatch between the fissure, the
 *       pial outline, and the Granular+WM outline. No direction is extrapolated beyond
 *       what the user's own trace already establishes.</li>
 *   <li><b>Partition the Granular layer</b> ({@code GranularWM \ WhiteMatter}) the same
 *       way, using each fissure's granular portion (crossing&rarr;WM end).</li>
 *   <li><b>For each stage independently</b>, try a small set of strip widths (as
 *       fractions of that stage's own local cut length, thinnest first) and keep the
 *       first one that yields the expected N+1 topologically-clean pieces covering most of
 *       the stage's area. In practice the thinnest candidate almost always succeeds once
 *       the width comparison is made against realistically-spaced boundary vertices; the
 *       other candidates exist only as a fallback for unusually dense tracing.</li>
 *   <li><b>Combine</b> each lobule's Molecular piece and Granular piece into one region
 *       (their union). {@link org.cerebellum.morphometry.geometry.PartitionClipper}
 *       intersects this with Granular/Molecular separately downstream, so the union is
 *       measurement-neutral &mdash; it just carries both pieces together.</li>
 * </ol>
 */
public final class FissurePartitioner {

    /**
     * Anatomical subsection labels for the standard rodent vermis scheme (2Cb nearest the
     * Purkinje start), used when there are exactly 7 fissures. See {@link #buildLobuleLabels}.
     */
    private static final String[] STANDARD_LOBULE_LABELS = {
            "2Cb", "3Cb", "4/5Cb", "6Cb", "7Cb", "8Cb", "9Cb", "10Cb"
    };

    /**
     * Builds subsection labels for {@code fissureCount} fissures, which produce {@code
     * fissureCount + 1} subsections. Ten lobules across 7 fissures (2Cb, 3Cb, 4/5Cb, 6Cb,
     * 7Cb, 8Cb, 9Cb, 10Cb — lobule 1 is conventionally fused/not separately measured) is the
     * standard scheme for a midline sagittal section of rodent vermis, but it isn't
     * universal: off-midline sagittal cuts, coronal or horizontal sections, damaged tissue,
     * and other species all have a different lobule count or don't follow this numbering at
     * all. Rather than assume the standard scheme always applies, this only uses the named
     * labels when the fissure count actually matches it (7); any other count gets generic
     * "Section N" labels instead, since a specific anatomical name would be a guess.
     */
    private static String[] buildLobuleLabels(int fissureCount) {
        if (fissureCount == STANDARD_LOBULE_LABELS.length - 1) {
            return STANDARD_LOBULE_LABELS;
        }
        String[] labels = new String[fissureCount + 1];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = "Section " + (i + 1);
        }
        return labels;
    }

    /**
     * Candidate strip half-widths to try, each expressed as a fraction of the current
     * stage's own average local cut length. Tried thinnest-first; the first one that
     * yields exactly N+1 valid pieces (N = number of fissures) covering most of the
     * stage's area is used. Three
     * candidates spanning a wide range are enough in practice — Java2D's {@code Area}
     * turned out to be robust across a wide width range once strips are compared against
     * a boundary with realistic (not pathologically dense) vertex spacing, so this exists
     * as a safety net for unusually dense tracing rather than as the primary mechanism.
     */
    private static final double[] WIDTH_FRACTION_CANDIDATES = {0.02, 0.06, 0.15};
    private static final double MIN_ABS_HALF_WIDTH_PX = 1.0;

    /** A width candidate is accepted only if the surviving pieces retain at least this much of the stage's area. */
    private static final double MIN_ACCEPTABLE_COVERAGE = 0.75;

    /** Small overshoot (as a fraction of the cut sub-path's own length) added past each end
     * of a fissure's molecular/granular portion, to guarantee a clean crossing despite
     * ordinary hand-tracing mismatch between the fissure and the layer boundary it needs
     * to fully cross (e.g. the fissure's WM-adjacent end not landing exactly on the White
     * Matter outline). */
    private static final double ENDPOINT_OVERSHOOT_FRACTION = 0.25;
    private static final double MIN_ABS_OVERSHOOT_PX = 8.0;

    /** Pieces smaller than this fraction of the stage's own base-shape area are treated as artifacts. */
    private static final double MIN_PIECE_AREA_FRACTION = 0.005; // 0.5%

    private FissurePartitioner() {
    }

    public static PartitionSet partition(LayerSet layers) {
        List<PolygonRoi> rawFissures = layers.getFissures();
        if (rawFissures.isEmpty()) {
            throw new IllegalStateException(
                    "FissurePartitioner requires at least 1 fissure (validated upstream); got 0");
        }

        PolygonRoi purkinje = layers.getPurkinje();
        Point2D.Double[] purkPoints     = GeometryUtils.extractPoints(purkinje);
        double[]         purkCumulative = GeometryUtils.cumulativeLengths(purkPoints);
        double           purkTotalLength = purkCumulative[purkCumulative.length - 1];
        Point2D.Double[] cerebellumBoundary = GeometryUtils.extractPoints(layers.getCerebellum());

        // -----------------------------------------------------------------------
        // Orient each fissure pial→WM (fissures are traced across the full tissue depth,
        // not stopped exactly at the Purkinje line — see class javadoc), then find where
        // each one crosses the Purkinje line. That crossing point splits the fissure into
        // its molecular portion (pial end→crossing) and granular portion (crossing→WM
        // end), and its arc-length position along Purkinje gives the 2Cb→10Cb order.
        // -----------------------------------------------------------------------
        List<OrientedFissure> oriented = new ArrayList<>(rawFissures.size());
        for (PolygonRoi fissure : rawFissures) {
            Point2D.Double[] raw = GeometryUtils.extractPoints(fissure);
            double d0    = GeometryUtils.nearestPointOnPolygon(cerebellumBoundary, raw[0], true).distance(raw[0]);
            double dLast = GeometryUtils.nearestPointOnPolygon(cerebellumBoundary, raw[raw.length - 1], true)
                    .distance(raw[raw.length - 1]);
            Point2D.Double[] pts = (d0 <= dLast) ? raw : reversed(raw);

            Crossing crossing = findPurkinjeCrossing(pts, purkPoints, purkCumulative);
            oriented.add(new OrientedFissure(pts, crossing));
        }
        oriented.sort(Comparator.comparingDouble(f -> f.crossing.purkinjeArc));

        int      n         = oriented.size(); // however many fissures were traced
        double[] attachArc = new double[n];
        for (int i = 0; i < n; i++) {
            attachArc[i] = oriented.get(i).crossing.purkinjeArc;
        }
        String[] labels = buildLobuleLabels(n); // n+1 subsections; anatomical names only when n == 7

        // -----------------------------------------------------------------------
        // STAGE 1: Molecular layer = Cerebellum \ GranularWM (see class javadoc for the
        // algebraic identity). Cuts are each fissure's own pial-end→crossing portion.
        // -----------------------------------------------------------------------
        ShapeRoi molecularBase = BooleanROIProcessor.subtract(layers.getCerebellum(), layers.getGranularWM());
        List<Segment> molecularCuts = new ArrayList<>(n);
        for (OrientedFissure f : oriented) {
            double[] cum = GeometryUtils.cumulativeLengths(f.points);
            Point2D.Double[] outerPart = pathBefore(f.points, cum, f.crossing.pathArc, f.crossing.point);
            molecularCuts.add(extendedSegment(outerPart));
        }
        List<LabeledPiece> molecularPieces =
                partitionRing(molecularBase, molecularCuts, attachArc, purkPoints, purkCumulative, "molecular layer");

        // -----------------------------------------------------------------------
        // STAGE 2: Granular layer = GranularWM \ WhiteMatter. Cuts are each fissure's own
        // crossing→WM-end portion (extended slightly past the WM boundary for a clean cut).
        // -----------------------------------------------------------------------
        ShapeRoi granularBase = BooleanROIProcessor.subtract(layers.getGranularWM(), layers.getWhiteMatter());
        List<Segment> granularCuts = new ArrayList<>(n);
        for (OrientedFissure f : oriented) {
            double[] cum = GeometryUtils.cumulativeLengths(f.points);
            Point2D.Double[] innerPart = pathAfter(f.points, cum, f.crossing.pathArc, f.crossing.point);
            granularCuts.add(extendedSegment(innerPart));
        }
        List<LabeledPiece> granularPieces =
                partitionRing(granularBase, granularCuts, attachArc, purkPoints, purkCumulative, "granular layer");

        // -----------------------------------------------------------------------
        // Combine: each lobule's region is the union of its Molecular and Granular pieces,
        // matched by which nominal lobule slot each piece actually landed in (not by list
        // position — those only line up when a stage found every piece).
        // -----------------------------------------------------------------------
        ShapeRoi[] molecularByLabel = bucketByLabel(molecularPieces, labels.length);
        ShapeRoi[] granularByLabel  = bucketByLabel(granularPieces, labels.length);

        List<String> missingBoth = new ArrayList<>();
        List<String> missingOneLayer = new ArrayList<>();
        List<PartitionSet.Partition> partitions = new ArrayList<>();
        for (int i = 0; i < labels.length; i++) {
            ShapeRoi mol = molecularByLabel[i];
            ShapeRoi gran = granularByLabel[i];
            if (mol == null && gran == null) {
                missingBoth.add(labels[i]);
                continue;
            }
            if (mol == null || gran == null) {
                missingOneLayer.add(labels[i] + " (missing " + (mol == null ? "molecular" : "granular") + ")");
            }
            ShapeRoi combined = (mol == null) ? new ShapeRoi(gran)
                    : (gran == null) ? new ShapeRoi(mol)
                    : new ShapeRoi(mol).or(new ShapeRoi(gran));
            double arcStart = (i == 0) ? 0.0            : attachArc[i - 1];
            double arcEnd   = (i >= n) ? purkTotalLength : attachArc[i];
            partitions.add(new PartitionSet.Partition(labels[i], combined, arcStart, arcEnd));
        }

        if (!missingBoth.isEmpty() || !missingOneLayer.isEmpty()) {
            StringBuilder msg = new StringBuilder("[Cerebellar Morphometry] Warning: partitioning did not "
                    + "cleanly separate every lobule (a fissure likely doesn't fully cross one of the layers "
                    + "at that boundary — check for a fissure that's too short, cuts across its fold at an "
                    + "angle, or veers into a neighbouring fold).");
            if (!missingBoth.isEmpty()) {
                msg.append(" Not found in either layer (merged into a neighbour and dropped): ")
                        .append(String.join(", ", missingBoth)).append(".");
            }
            if (!missingOneLayer.isEmpty()) {
                msg.append(" Found in only one layer: ").append(String.join(", ", missingOneLayer)).append(".");
            }
            IJ.log(msg.toString());
        }

        // Overlay cut-lines: each fissure's own traced path already spans pial→WM.
        List<PolygonRoi> overlayLines = new ArrayList<>(n);
        for (OrientedFissure f : oriented) {
            overlayLines.add(toPolygonRoi(f.points, Roi.POLYLINE));
        }

        return new PartitionSet(partitions, overlayLines);
    }

    // -----------------------------------------------------------------------
    // Core: subtract-and-split one "ring" shape with an adaptive strip-width search.
    // -----------------------------------------------------------------------

    /**
     * Groups labeled pieces into a {@code labelCount}-slot array by their {@link
     * LabeledPiece#labelIndex}, unioning together any pieces that landed in the same
     * nominal slot (this can happen if one lobule's own region got fragmented into two
     * disconnected pieces). A slot stays {@code null} if no piece landed there at all.
     */
    private static ShapeRoi[] bucketByLabel(List<LabeledPiece> pieces, int labelCount) {
        ShapeRoi[] byLabel = new ShapeRoi[labelCount];
        for (LabeledPiece p : pieces) {
            if (byLabel[p.labelIndex] == null) {
                byLabel[p.labelIndex] = new ShapeRoi(p.shape);
            } else {
                byLabel[p.labelIndex] = byLabel[p.labelIndex].or(new ShapeRoi(p.shape));
            }
        }
        return byLabel;
    }

    /**
     * Which of the {@code attachArc.length + 1} nominal lobule slots {@code arc} falls
     * into. Used to label pieces by where they actually are, rather than by their position
     * in a possibly-incomplete list — see {@link #partition}.
     */
    private static int labelIndexFor(double arc, double[] attachArc) {
        int idx = 0;
        for (double boundary : attachArc) {
            if (arc >= boundary) {
                idx++;
            }
        }
        return Math.min(idx, attachArc.length);
    }

    private static final class LabeledPiece {
        final ShapeRoi shape;
        final int labelIndex;

        LabeledPiece(ShapeRoi shape, int labelIndex) {
            this.shape = shape;
            this.labelIndex = labelIndex;
        }
    }

    /**
     * Subtracts thin strips built from {@code cuts} out of {@code baseShape} and splits the
     * result, trying increasingly wide strips until one yields exactly {@code cuts.size()+1}
     * valid pieces covering most of {@code baseShape}'s area. Returns pieces labeled by which
     * nominal lobule slot their centroid actually falls into (see {@link #labelIndexFor}) —
     * not by position in the list, since that position is only meaningful when every piece
     * was found.
     *
     * <p>Works on a rasterized pixel mask with 8-connected flood-fill labeling, not on
     * {@code ShapeRoi}/{@code Area} directly — see {@link RasterSplitUtils} for why.</p>
     */
    private static List<LabeledPiece> partitionRing(ShapeRoi baseShape, List<Segment> cuts, double[] attachArc,
            Point2D.Double[] purkPoints, double[] purkCumulative, String stageName) {

        Rectangle bounds = baseShape.getBounds();
        int margin = (int) Math.max(50, 0.08 * Math.max(bounds.width, bounds.height));
        Rectangle canvas = new Rectangle(bounds.x - margin, bounds.y - margin,
                bounds.width + 2 * margin, bounds.height + 2 * margin);
        int w = canvas.width, h = canvas.height;

        boolean[] baseMask = RasterSplitUtils.rasterize(baseShape, canvas);
        long baseArea = countTrue(baseMask);
        long minPieceArea = (long) (baseArea * MIN_PIECE_AREA_FRACTION);
        int expected = cuts.size() + 1;

        double avgLen = 0;
        for (Segment s : cuts) {
            avgLen += s.refLength;
        }
        avgLen /= cuts.size();

        List<RasterSplitUtils.Component> bestFiltered = null;
        long   bestArea = -1;
        int    bestDiff = Integer.MAX_VALUE;

        for (double frac : WIDTH_FRACTION_CANDIDATES) {
            double halfWidth = Math.max(MIN_ABS_HALF_WIDTH_PX, avgLen * frac);

            boolean[] stripsMask = new boolean[w * h];
            for (Segment s : cuts) {
                Point2D.Double[] stripPts = GeometryUtils.polylineStrip(s.pts, halfWidth);
                Roi stripRoi = toPolygonRoi(stripPts, Roi.POLYGON);
                RasterSplitUtils.orInPlace(stripsMask, RasterSplitUtils.rasterize(stripRoi, canvas));
            }

            boolean[] divided = baseMask.clone();
            RasterSplitUtils.subtractInPlace(divided, stripsMask);

            List<RasterSplitUtils.Component> raw = RasterSplitUtils.connectedComponents(divided, w, h);
            List<RasterSplitUtils.Component> filtered = new ArrayList<>();
            long filteredArea = 0;
            for (RasterSplitUtils.Component c : raw) {
                if (c.size() >= minPieceArea) {
                    filtered.add(c);
                    filteredArea += c.size();
                }
            }

            boolean countOk    = filtered.size() == expected;
            boolean coverageOk = filteredArea >= baseArea * MIN_ACCEPTABLE_COVERAGE;
            if (countOk && coverageOk) {
                return traceAndLabel(filtered, canvas, w, h, purkPoints, purkCumulative, attachArc);
            }

            int diff = Math.abs(filtered.size() - expected);
            if (diff < bestDiff || (diff == bestDiff && filteredArea > bestArea)) {
                bestDiff     = diff;
                bestArea     = filteredArea;
                bestFiltered = filtered;
            }
        }

        IJ.log("[Cerebellar Morphometry] Warning: could not find a strip width that cleanly splits the "
                + stageName + " into " + expected + " pieces after trying " + WIDTH_FRACTION_CANDIDATES.length
                + " candidate widths. Using the closest attempt (" + (bestFiltered == null ? 0 : bestFiltered.size())
                + " pieces). Consider retracing the fissures or layer boundaries with smoother lines.");
        return traceAndLabel(bestFiltered == null ? new ArrayList<>() : bestFiltered, canvas, w, h,
                purkPoints, purkCumulative, attachArc);
    }

    private static long countTrue(boolean[] mask) {
        long n = 0;
        for (boolean b : mask) {
            if (b) {
                n++;
            }
        }
        return n;
    }

    /**
     * Traces each accepted component's outline into a {@link ShapeRoi} (absolute image
     * coordinates) and labels each with which nominal lobule slot its centroid
     * falls into (see {@link #labelIndexFor}). Tracing only happens here, for the winning
     * candidate — not during the width search. If two components land in the same nominal
     * slot (rare — would mean one lobule's own piece got fragmented in two), both are kept
     * and unioned by the caller.
     */
    private static List<LabeledPiece> traceAndLabel(List<RasterSplitUtils.Component> components, Rectangle canvas,
            int w, int h, Point2D.Double[] purkPoints, double[] purkCumulative, double[] attachArc) {
        List<LabeledPiece> result = new ArrayList<>(components.size());
        for (RasterSplitUtils.Component c : components) {
            Point2D.Double centroid = new Point2D.Double(c.centroidX() + canvas.x, c.centroidY() + canvas.y);
            GeometryUtils.Projection proj = GeometryUtils.project(purkPoints, purkCumulative, centroid);
            Roi traced = RasterSplitUtils.traceComponent(c, w, h, canvas);
            int labelIndex = labelIndexFor(proj.arcLength, attachArc);
            result.add(new LabeledPiece(new ShapeRoi(traced), labelIndex));
        }
        return result;
    }

    // -----------------------------------------------------------------------
    // Inner types
    // -----------------------------------------------------------------------

    private static final class OrientedFissure {
        final Point2D.Double[] points; // index 0 = pial end, last = WM end
        final Crossing crossing;       // where this fissure crosses the Purkinje line

        OrientedFissure(Point2D.Double[] points, Crossing crossing) {
            this.points   = points;
            this.crossing = crossing;
        }
    }

    /** Where a fissure's own path crosses the Purkinje line. */
    private static final class Crossing {
        final Point2D.Double point;
        final double pathArc;     // arc-length along the fissure's own path
        final double purkinjeArc; // arc-length along the Purkinje polyline

        Crossing(Point2D.Double point, double pathArc, double purkinjeArc) {
            this.point       = point;
            this.pathArc     = pathArc;
            this.purkinjeArc = purkinjeArc;
        }
    }

    private static final class Segment {
        final Point2D.Double[] pts; // cut polyline, already extended past both true endpoints
        /** True local layer thickness (before overshoot padding) — used to scale strip width. */
        final double refLength;

        Segment(Point2D.Double[] pts, double refLength) {
            this.pts = pts;
            this.refLength = refLength;
        }
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Finds where {@code fissurePts} (a short pial-to-WM traced path) comes closest to the
     * Purkinje polyline, by sampling finely along the fissure's own path. This is the point
     * used both to split the fissure into its molecular and granular portions, and (via its
     * Purkinje arc-length) to order lobules 2Cb→10Cb.
     */
    private static Crossing findPurkinjeCrossing(Point2D.Double[] fissurePts, Point2D.Double[] purkPts, double[] purkCumulative) {
        double[] fissureCum = GeometryUtils.cumulativeLengths(fissurePts);
        double totalLen = fissureCum[fissureCum.length - 1];
        int samples = (int) Math.max(20, Math.min(300, totalLen));

        double bestDist = Double.POSITIVE_INFINITY;
        Point2D.Double bestPoint = fissurePts[0];
        double bestPathArc = 0;
        double bestPurkArc = 0;
        for (int i = 0; i <= samples; i++) {
            double arc = totalLen * i / samples;
            Point2D.Double p = GeometryUtils.pointAtArcLength(fissurePts, fissureCum, arc);
            GeometryUtils.Projection proj = GeometryUtils.project(purkPts, purkCumulative, p);
            if (proj.distance < bestDist) {
                bestDist    = proj.distance;
                bestPoint   = p;
                bestPathArc = arc;
                bestPurkArc = proj.arcLength;
            }
        }
        return new Crossing(bestPoint, bestPathArc, bestPurkArc);
    }

    /** The portion of {@code pts} from its start up to {@code splitArc}, ending exactly at {@code splitPoint}. */
    private static Point2D.Double[] pathBefore(Point2D.Double[] pts, double[] cum, double splitArc, Point2D.Double splitPoint) {
        List<Point2D.Double> result = new ArrayList<>();
        for (int i = 0; i < pts.length; i++) {
            if (cum[i] < splitArc) {
                result.add(pts[i]);
            } else {
                break;
            }
        }
        if (result.isEmpty()) {
            result.add(pts[0]); // degenerate fallback: split point landed exactly on the first vertex
        }
        result.add(splitPoint);
        return result.toArray(new Point2D.Double[0]);
    }

    /** The portion of {@code pts} from {@code splitPoint} onward to its end. */
    private static Point2D.Double[] pathAfter(Point2D.Double[] pts, double[] cum, double splitArc, Point2D.Double splitPoint) {
        List<Point2D.Double> result = new ArrayList<>();
        result.add(splitPoint);
        for (int i = 0; i < pts.length; i++) {
            if (cum[i] > splitArc) {
                result.add(pts[i]);
            }
        }
        if (result.size() < 2) {
            result.add(pts[pts.length - 1]); // degenerate fallback: split point landed exactly on the last vertex
        }
        return result.toArray(new Point2D.Double[0]);
    }

    /**
     * Builds a cut {@link Segment} from a traced sub-path by extending its two end segments
     * a small distance past their true endpoints — enough to absorb ordinary mismatch between
     * this path and the layer boundary it needs to fully cross, without extrapolating any
     * direction that wasn't already in the user's own trace.
     */
    private static Segment extendedSegment(Point2D.Double[] path) {
        double refLength = pathLength(path);
        double overshoot = Math.max(MIN_ABS_OVERSHOOT_PX, refLength * ENDPOINT_OVERSHOOT_FRACTION);

        Point2D.Double startDir = GeometryUtils.normalize(GeometryUtils.subtract(path[0], path[1]));
        Point2D.Double endDir   = GeometryUtils.normalize(GeometryUtils.subtract(path[path.length - 1], path[path.length - 2]));
        Point2D.Double newStart = GeometryUtils.add(path[0], GeometryUtils.scale(startDir, overshoot));
        Point2D.Double newEnd   = GeometryUtils.add(path[path.length - 1], GeometryUtils.scale(endDir, overshoot));

        Point2D.Double[] extended = new Point2D.Double[path.length];
        extended[0] = newStart;
        extended[path.length - 1] = newEnd;
        for (int i = 1; i < path.length - 1; i++) {
            extended[i] = path[i];
        }
        return new Segment(extended, refLength);
    }

    private static double pathLength(Point2D.Double[] pts) {
        double len = 0;
        for (int i = 1; i < pts.length; i++) {
            len += pts[i - 1].distance(pts[i]);
        }
        return len;
    }

    private static Point2D.Double[] reversed(Point2D.Double[] arr) {
        Point2D.Double[] rev = new Point2D.Double[arr.length];
        for (int i = 0; i < arr.length; i++) {
            rev[i] = arr[arr.length - 1 - i];
        }
        return rev;
    }

    private static PolygonRoi toPolygonRoi(Point2D.Double[] pts, int type) {
        int     n  = pts.length;
        float[] xs = new float[n];
        float[] ys = new float[n];
        for (int i = 0; i < n; i++) {
            xs[i] = (float) pts[i].x;
            ys[i] = (float) pts[i].y;
        }
        return new PolygonRoi(xs, ys, n, type);
    }
}
