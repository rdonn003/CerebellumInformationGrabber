package org.cerebellum.morphometry.measurement;

import ij.ImagePlus;
import ij.measure.Calibration;
import org.cerebellum.morphometry.geometry.*;
import org.cerebellum.morphometry.model.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Ties together every geometry class and produces the complete {@link MorphometryResults}
 * object. This is the single call the plugin controller makes after validation passes.
 *
 * <p>Execution order:
 * <ol>
 *   <li>{@link LayerConstructor} &rarr; Grey, Granular, Molecular shapes for the whole cerebellum.</li>
 *   <li>{@link FissurePartitioner} &rarr; N+1 lobule regions (from N traced fissures) plus their Purkinje arc-length bounds.</li>
 *   <li>{@link PartitionClipper} &rarr; per-partition Granular and Molecular clips.</li>
 *   <li>Area and length measurement using {@link BooleanROIProcessor} and
 *       {@link PurkinjeLengthCalculator}.</li>
 * </ol>
 * </p>
 */
public final class MeasurementEngine {

    private MeasurementEngine() {
    }

    /**
     * Full pipeline: geometry construction &rarr; subdivision &rarr; measurement.
     *
     * @param layers the validated, typed ROI bundle
     * @param imp    the active image (needed for calibrated area; pixel content is never read)
     * @return all numbers needed to populate the output table
     */
    public static MorphometryResults measure(LayerSet layers, ImagePlus imp) {

        // Step 1: build the three whole-cerebellum layers.
        ConstructedLayers constructed = LayerConstructor.construct(layers);

        // Step 2: cut into lobule partitions (N+1 from N traced fissures).
        PartitionSet partitionSet = FissurePartitioner.partition(layers);

        // Step 3: clip each partition's granular and molecular shapes.
        List<PartitionClipper.ClippedPartition> clipped =
                PartitionClipper.clip(constructed, partitionSet);

        // Step 4: whole-cerebellum measurements.
        double cerebellumArea  = BooleanROIProcessor.area(layers.getCerebellum(), imp);
        double greyMatterArea  = BooleanROIProcessor.area(constructed.getGrey(), imp);
        double granularArea    = BooleanROIProcessor.area(constructed.getGranular(), imp);
        double molecularArea   = BooleanROIProcessor.area(constructed.getMolecular(), imp);
        double totalPurkinje   = PurkinjeLengthCalculator.totalLength(layers.getPurkinje(), imp);
        double totalPurkinjeArea = PurkinjeLengthCalculator.totalArea(layers.getPurkinje(), imp);

        // Step 5: per-subsection measurements.
        List<MorphometryResults.SubsectionResult> subsections = new ArrayList<>(clipped.size());
        List<PartitionSet.Partition> partitions = partitionSet.getPartitions();
        for (int i = 0; i < clipped.size(); i++) {
            PartitionClipper.ClippedPartition cp = clipped.get(i);
            PartitionSet.Partition p = partitions.get(i);

            double subGranular  = BooleanROIProcessor.area(cp.granular, imp);
            double subMolecular = BooleanROIProcessor.area(cp.molecular, imp);
            double subPurkinje  = PurkinjeLengthCalculator.lengthBetween(
                    layers.getPurkinje(), imp,
                    p.getPurkinjeArcStart(), p.getPurkinjeArcEnd());

            subsections.add(new MorphometryResults.SubsectionResult(
                    cp.label, subGranular, subMolecular, subPurkinje));
        }

        // Determine unit strings from the image calibration.
        Calibration cal = imp.getCalibration();
        String unit      = (cal != null && cal.getUnit() != null) ? cal.getUnit() : "px";
        String areaUnit  = unit + "\u00B2"; // e.g. "µm²"
        String lengthUnit = unit;

        return new MorphometryResults(
                cerebellumArea, greyMatterArea, granularArea, molecularArea, totalPurkinje, totalPurkinjeArea,
                subsections, areaUnit, lengthUnit);
    }

    /**
     * Exposes the intermediate geometry for the overlay renderer without re-running the
     * full measurement pipeline. Returns an object carrying constructed layers,
     * partitions, and clips so {@link org.cerebellum.morphometry.visualization.OverlayRenderer}
     * can use them directly.
     */
    public static IntermediateGeometry buildGeometry(LayerSet layers) {
        ConstructedLayers constructed = LayerConstructor.construct(layers);
        PartitionSet partitionSet     = FissurePartitioner.partition(layers);
        List<PartitionClipper.ClippedPartition> clipped =
                PartitionClipper.clip(constructed, partitionSet);
        return new IntermediateGeometry(constructed, partitionSet, clipped);
    }

    /** Carries the intermediate geometry objects so they can be passed to the overlay renderer. */
    public static final class IntermediateGeometry {
        public final ConstructedLayers constructed;
        public final PartitionSet partitionSet;
        public final List<PartitionClipper.ClippedPartition> clipped;

        public IntermediateGeometry(ConstructedLayers constructed, PartitionSet partitionSet,
                                     List<PartitionClipper.ClippedPartition> clipped) {
            this.constructed  = constructed;
            this.partitionSet = partitionSet;
            this.clipped      = clipped;
        }
    }
}
