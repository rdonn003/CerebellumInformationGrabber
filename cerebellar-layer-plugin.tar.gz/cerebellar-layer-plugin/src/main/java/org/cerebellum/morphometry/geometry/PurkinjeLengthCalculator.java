package org.cerebellum.morphometry.geometry;

import ij.ImagePlus;
import ij.gui.PolygonRoi;
import ij.measure.Calibration;

import java.awt.geom.Point2D;

/**
 * Calibrated length of the Purkinje polyline, as a whole and per fissure-defined
 * subsection. Per-subsection length does not need any polygon/line clipping: each
 * partition's boundaries were built (in {@link FissurePartitioner}) to pass through
 * specific, known arc-length positions along this same polyline, so a subsection's
 * Purkinje length is simply the calibrated length of the polyline between those two
 * positions.
 */
public final class PurkinjeLengthCalculator {

    private PurkinjeLengthCalculator() {
    }

    /** Total calibrated length of the whole Purkinje polyline. */
    public static double totalLength(PolygonRoi purkinje, ImagePlus imp) {
        return lengthBetween(purkinje, imp, 0.0, pixelArcLength(purkinje));
    }

    /** Total length of the polyline, measured in plain pixel-space arc length (uncalibrated). */
    public static double pixelArcLength(PolygonRoi purkinje) {
        Point2D.Double[] points = GeometryUtils.extractPoints(purkinje);
        double[] cumulative = GeometryUtils.cumulativeLengths(points);
        return cumulative[cumulative.length - 1];
    }

    /**
     * Calibrated length of the portion of the Purkinje polyline between two pixel-space
     * arc-length positions (as produced by {@link FissurePartitioner}, which works in
     * pixel space throughout). Handles anisotropic pixel calibration correctly by scaling
     * each x/y component independently before computing each sub-segment's Euclidean
     * length, the same way {@code ij.gui.PolygonRoi#getLength()} calibrates a whole line.
     */
    public static double lengthBetween(PolygonRoi purkinje, ImagePlus imp, double pixelArcStart, double pixelArcEnd) {
        Point2D.Double[] points = GeometryUtils.extractPoints(purkinje);
        double[] cumulative = GeometryUtils.cumulativeLengths(points);

        Calibration cal = imp.getCalibration();
        double pixelWidth = cal != null ? cal.pixelWidth : 1.0;
        double pixelHeight = cal != null ? cal.pixelHeight : 1.0;

        double total = 0.0;
        Point2D.Double prev = GeometryUtils.pointAtArcLength(points, cumulative, pixelArcStart);
        for (int i = 0; i < points.length; i++) {
            if (cumulative[i] <= pixelArcStart) {
                continue;
            }
            if (cumulative[i] >= pixelArcEnd) {
                break;
            }
            total += calibratedDistance(prev, points[i], pixelWidth, pixelHeight);
            prev = points[i];
        }
        Point2D.Double end = GeometryUtils.pointAtArcLength(points, cumulative, pixelArcEnd);
        total += calibratedDistance(prev, end, pixelWidth, pixelHeight);
        return total;
    }

    private static double calibratedDistance(Point2D.Double a, Point2D.Double b, double pixelWidth, double pixelHeight) {
        double dx = (b.x - a.x) * pixelWidth;
        double dy = (b.y - a.y) * pixelHeight;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
