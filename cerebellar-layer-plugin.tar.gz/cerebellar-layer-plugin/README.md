# Cerebellar Layer Quantification Plugin — FIJI/ImageJ

A professional FIJI/ImageJ2 plugin for ROI-based quantitative morphometry of
Nissl-stained cerebellar histology sections. **No pixel segmentation is performed** — the
plugin derives all measurements from user-drawn ROI geometry alone.

---

## What it measures

| Measurement | Method |
|---|---|
| **Cerebellum area** | Area of the Cerebellum ROI |
| **Grey Matter area** | Cerebellum − White Matter |
| **Granular Layer area** | (Granular+WM) − White Matter |
| **Molecular Layer area** | Grey Matter − Granular Layer |
| **Purkinje length** | Arc-length of the Purkinje polyline |

All five measurements are computed for the **whole cerebellum**, and the last three are
also computed for each of the **eight fissure-defined lobule subsections** (2Cb–10Cb).

---

## Prerequisites

| Requirement | Version |
|---|---|
| Java (JDK) | ≥ 17 |
| Maven | ≥ 3.8 |
| FIJI / ImageJ | Any recent version |

---

## Build

```bash
git clone <this-repo>
cd cerebellar-layer-plugin
mvn package
```

The `mvn package` step produces a single self-contained jar (with all dependencies
shaded in) at:

```
target/cerebellar-layer-plugin-1.0.0.jar
```

> **Offline / corporate network?** The pom.xml depends on `net.imagej:ij`, `org.scijava:scijava-common`, and `org.apache.poi:poi-ooxml`. If Maven Central is unavailable, install the jars into your local Maven repository with `mvn install:install-file` before building. Debian/Ubuntu users can install `libij-java` and `libapache-poi-java` via apt and register them with Maven's Debian integration.

---

## Installation

1. Copy `target/cerebellar-layer-plugin-1.0.0.jar` into FIJI's `plugins/` folder.
2. Restart FIJI (or run *Help → Refresh Menus*).
3. The plugin appears under **Plugins → Cerebellar Morphometry → Quantify Layers...**.

---

## User workflow

### 1. Open your image
Open the Nissl-stained cerebellar section in FIJI.  
Set the pixel calibration (*Image → Properties* or *Image → Calibration*) if you have a
known scale. The plugin uses whatever calibration is present — without calibration, areas
are reported in px² and lengths in px.

### 2. Draw and name the ROIs

Open the **ROI Manager** (*Analyze → Tools → ROI Manager*) and draw the following ROIs.
Names are matched case-insensitively by substring — as long as the required substring is
in the name it will be recognised.

| ROI | ROI type | Required substring in name |
|---|---|---|
| Entire cerebellum outline | Closed polygon | `cerebellum` |
| Granular layer + White Matter | Closed polygon | `granular` |
| Purkinje cell line | Open polyline | `purkinje` |
| White Matter only *(optional)* | Closed polygon | `white` or exactly `wm` |
| Fissure 1 *(optional)* | Open polyline | `fissure` |
| Fissure 2 *(optional)* | Open polyline | `fissure` |
| … | Open polyline | `fissure` |

Only three ROIs are required: the **Cerebellum** outline, the **Granular+WM** outline, and the
**Purkinje** line. **White Matter and fissures are optional.**

- **No White Matter** (some scan sections have no white-matter core at all — e.g. a peripheral
  cut through cortex only): that section is measured normally, but its Grey Matter and Granular
  Layer numbers won't have white matter excluded (there's nothing to subtract), and it is *not*
  split into lobules. Any fissures you traced anyway are ignored (with a note in the Log), since
  a section with no white matter isn't partitioned here — so if there's no white matter, you
  don't need to trace fissures either.
- **No fissures** (but White Matter present): the section is measured as a whole but not split
  into lobule subsections.

**Example ROI Manager names** (any order is fine):
```
Cerebellum
Granular+WM
WhiteMatter
Purkinje
Fissure1
Fissure2
Fissure3
Fissure4
Fissure5
Fissure6
Fissure7
```

#### Fissure tracing convention
Trace each fissure line **down the cleft** between two lobules, starting at the **pial surface**
(outer edge of the molecular layer) and heading inward. **Follow the curve of the sulcus** with a
segmented/freehand line (several points), rather than dropping a single straight two-point line
across the fold — a straight chord cuts across the folded cortical band at an angle and can shave
off spurious slivers or place the boundary through tissue rather than down the valley. The plugin
keeps your traced shape exactly and only extends the two ends, so the more faithfully the middle
follows the cleft, the cleaner the split.

You can stop the deep end wherever is convenient — at the **Purkinje cell line**, or deeper toward
the white matter; you do **not** need to land it precisely on any layer. From the part you trace,
the plugin extends the line along its own direction until it spans the full cerebellar thickness
(from just outside the pial surface to inside the white matter), which is what a lobule boundary
has to do. You may trace either end first; the plugin detects the pial end automatically.

> **Note on separately-traced pieces.** If you outline the cerebellum in several disconnected
> pieces (see *Multiple instances* below), fissures belong to whichever piece they sit in — a
> piece with no fissures simply isn't split into lobules. To get lobule detail across the whole
> section, trace fissures in each piece that needs splitting.

#### Nesting requirement
When present, the plugin checks that White Matter ⊂ Granular+WM ⊂ Cerebellum (within a 0.5% area
tolerance, and allowing deliberate contact at the peduncle). White Matter is optional; if it is
omitted, only Granular+WM ⊂ Cerebellum is relevant. Draw these ROIs to reflect the actual tissue
anatomy.

### 3. Run the plugin
*Plugins → Cerebellar Morphometry → Quantify Layers...*

An options dialog appears:

| Option | Effect |
|---|---|
| Show colour-coded layer overlay | Adds a vector overlay (see Overlay section) |
| Show per-lobule transparent fills | Adds distinct semitransparent fills for each lobule |
| Show ImageJ Results Table | Displays the measurement table interactively |
| Export CSV | Saves a UTF-8 comma-separated file |
| Export Excel (.xlsx) | Saves a formatted workbook |

If either export is selected, you will be prompted for a save directory. Files are named
after the image title (with non-alphanumeric characters replaced by underscores).

---

## Output table format

```
Measurement  | Cerebellum  | Grey Matter | Granular Layer | Molecular Layer | Purkinje
Area         | Total area  | Grey area   | Granular area  | Molecular area  |
Length       |             |             |                |                 | Total length
2Cb          |             |             | Area           | Area            | Length
3Cb          |             |             | Area           | Area            | Length
4/5Cb        |             |             | Area           | Area            | Length
6Cb          |             |             | Area           | Area            | Length
7Cb          |             |             | Area           | Area            | Length
8Cb          |             |             | Area           | Area            | Length
9Cb          |             |             | Area           | Area            | Length
10Cb         |             |             | Area           | Area            | Length
```

Areas are in calibrated area units (e.g. µm²); length is in calibrated linear units (e.g. µm).
Empty cells carry no measurement for that row/column combination.

---

## Overlay colours

| Layer | Colour |
|---|---|
| Grey Matter | Blue |
| Granular Layer | Green |
| Molecular Layer | Yellow |
| Purkinje line | Red |
| Partition boundaries | White |
| Per-lobule fills (optional) | 8 distinct hues |

The overlay is purely vector (non-destructive). To remove it: *Image → Overlay → Remove Overlay*.

---

## Architecture

```
org.cerebellum.morphometry
│   CerebellarMorphometryPlugin   ← ij.plugin.PlugIn entry point
│
├── model/
│   ├── LayerSet                  validated, typed input ROI bundle
│   ├── ConstructedLayers         three Boolean-derived whole-cerebellum shapes
│   ├── PartitionSet              eight lobule regions + Purkinje arc-length bounds
│   ├── MorphometryResults        final numbers (areas, lengths, per-subsection)
│   └── ValidationException       carries all problems found during validation
│
├── geometry/
│   ├── ROIValidator              name/type/nesting checks → LayerSet
│   ├── BooleanROIProcessor       defensive-copy ShapeRoi AND/OR/NOT + area measurement
│   ├── GeometryUtils             vector math, polyline arc-length, projection
│   ├── LayerConstructor          cerebellum − WM → Grey/Granular/Molecular
│   ├── FissurePartitioner        7 fissures → 8 half-plane partitions
│   ├── PartitionClipper          clips granular/molecular into per-partition shapes
│   └── PurkinjeLengthCalculator  calibrated arc-length, total and per-partition
│
├── measurement/
│   └── MeasurementEngine         orchestrates the full pipeline → MorphometryResults
│
├── export/
│   └── SpreadsheetExporter       ResultsTable + CSV + XLSX (exact spec layout)
│
└── visualization/
    └── OverlayRenderer           colour-coded vector overlay
```

---

## Partitioning algorithm (summary)

1. Each fissure is **oriented** pial→white-matter by the anatomical nesting depth of its two
   endpoints (inside White Matter is deeper than inside Granular+WM, which is deeper than inside
   the Cerebellum, which is deeper than outside it). This is robust to how tightly the vermis is
   folded, where a deep fissure end can sit close to a neighbouring folium's pial surface.
2. Each fissure's Purkinje-proximal crossing is projected onto the Purkinje polyline to
   determine its arc-length position. Sorting by arc-length gives the anatomical
   (lobule-2→lobule-10) order without any image-orientation assumptions.
3. Each fissure is turned into a **spanning cut**: the user's traced vertices are kept as-is,
   and the two ends are extended along their own tangents until the cut runs from just outside
   the Cerebellum outline to inside the White Matter. Extension stops as soon as it reaches its
   target, is distance-capped, and is skipped entirely if the target can't be reached along the
   traced direction (so a mis-aimed fissure is never shot blindly across the section).
4. Each spanning cut is thickened into a thin strip and subtracted **once** from the **Grey
   Matter** ring (`Cerebellum − White Matter`), splitting it into per-lobule footprints. A small
   set of strip widths is tried, thinnest first, keeping the first that cleanly separates the
   pieces over most of the grey matter's area. Any sub-threshold sliver a straight-line fissure
   shaves off a folded band is merged into its largest neighbour rather than kept as a spurious
   section (or dropped, which would lose its area).
5. Each lobule's **Molecular and Granular parts are derived from that single footprint** by
   intersecting it with the whole-cerebellum Molecular and Granular layers (`PartitionClipper`).
   Because both come from the same piece, a lobule's molecular and granular tissue always belong
   to the same lobule — the two layers are never split independently and paired, which is what
   previously fused unrelated regions when the layers fragmented differently.
6. Per-partition Purkinje length = calibrated arc-length between the two bounding fissures'
   crossing points (no separate polyline clipping needed).

---

## Troubleshooting

| Problem | Cause / fix |
|---|---|
| *"The ROI Manager is empty"* | Add at least the Cerebellum, Granular+WM, and Purkinje ROIs before running |
| *"More than one ROI matches Cerebellum"* | Rename or remove the extra ROI |
| No lobule subsections appear | The section has no White Matter, or no fissures were traced for it — both are needed to split a section into lobules (White Matter is otherwise optional) |
| *"WhiteMatter ROI is a polyline"* | Re-trace as a closed polygon in FIJI (only needed if you trace White Matter at all) |
| *"Granular+WM is not fully inside Cerebellum"* | Redraw Granular+WM so it is contained within the Cerebellum outline |
| Per-partition areas don't add up | Make sure each fissure is traced *down the cleft* between the two lobules it separates (following the valley, not cutting straight across a folium), and that it heads inward toward the white matter. The plugin extends the deep end for you, but only along the direction you traced — a fissure aimed across the tissue will be extended across the tissue. |
| Overlay looks wrong | Verify ROI nesting; run with subsection fills enabled to inspect the partition boundaries against the tissue |

---

## License
MIT — see `LICENSE` for details. Dependencies (ImageJ, SciJava, Apache POI) retain their
own respective licences.
