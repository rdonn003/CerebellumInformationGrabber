# Cerebellar Layer Quantification Plugin — FIJI/ImageJ

A professional FIJI/ImageJ2 plugin for ROI-based quantitative morphometry of
Nissl-stained cerebellar histology sections. **No pixel segmentation is performed** — the
plugin derives all measurements from user-drawn ROI geometry alone.

---

## What it measures

| Measurement | Method |
|---|---|
| **Cerebellum area** | Area of the Cerebellum ROI |
| **Grey Matter area** | Cerebellum − White Matter |
| **Granular Layer area** | (Granular+WM) − White Matter |
| **Molecular Layer area** | Grey Matter − Granular Layer |
| **Purkinje length** | Arc-length of the Purkinje polyline |

All five measurements are computed for the **whole cerebellum**, and the last three are
also computed for each of the **eight fissure-defined lobule subsections** (2Cb–10Cb).

---

## Prerequisites

| Requirement | Version |
|---|---|
| Java (JDK) | ≥ 17 |
| Maven | ≥ 3.8 |
| FIJI / ImageJ | Any recent version |

---

## Build

```bash
git clone <this-repo>
cd cerebellar-layer-plugin
mvn package
```

The `mvn package` step produces a single self-contained jar (with all dependencies
shaded in) at:

```
target/cerebellar-layer-plugin-1.0.0.jar
```

> **Offline / corporate network?** The pom.xml depends on `net.imagej:ij`, `org.scijava:scijava-common`, and `org.apache.poi:poi-ooxml`. If Maven Central is unavailable, install the jars into your local Maven repository with `mvn install:install-file` before building. Debian/Ubuntu users can install `libij-java` and `libapache-poi-java` via apt and register them with Maven's Debian integration.

---

## Installation

1. Copy `target/cerebellar-layer-plugin-1.0.0.jar` into FIJI's `plugins/` folder.
2. Restart FIJI (or run *Help → Refresh Menus*).
3. The plugin appears under **Plugins → Cerebellar Morphometry → Quantify Layers...**.

---

## User workflow

### 1. Open your image
Open the Nissl-stained cerebellar section in FIJI.  
Set the pixel calibration (*Image → Properties* or *Image → Calibration*) if you have a
known scale. The plugin uses whatever calibration is present — without calibration, areas
are reported in px² and lengths in px.

### 2. Draw and name the ROIs

Open the **ROI Manager** (*Analyze → Tools → ROI Manager*) and draw the following ROIs.
Names are matched case-insensitively by substring — as long as the required substring is
in the name it will be recognised.

| ROI | ROI type | Required substring in name |
|---|---|---|
| Entire cerebellum outline | Closed polygon | `cerebellum` |
| Granular layer + White Matter | Closed polygon | `granular` |
| White Matter only | Closed polygon | `white` or exactly `wm` |
| Purkinje cell line | Open polyline | `purkinje` |
| Fissure 1 | Open polyline | `fissure` |
| Fissure 2 | Open polyline | `fissure` |
| … (7 total) | Open polyline | `fissure` |
| Fissure 7 | Open polyline | `fissure` |

**Example ROI Manager names** (any order is fine):
```
Cerebellum
Granular+WM
WhiteMatter
Purkinje
Fissure1
Fissure2
Fissure3
Fissure4
Fissure5
Fissure6
Fissure7
```

#### Fissure tracing convention
Each fissure line should run from the **pial surface** (outer edge of the molecular layer)
to the **Purkinje cell line**. It does not need to continue into the granular layer —
the plugin extends each fissure line automatically to cross the full cerebellar thickness.
You may trace either end first; the plugin detects the Purkinje-proximal end automatically.

#### Nesting requirement
The plugin validates that White Matter ⊂ Granular+WM ⊂ Cerebellum (within 0.5% area
tolerance). Draw these ROIs to reflect the actual tissue anatomy.

### 3. Run the plugin
*Plugins → Cerebellar Morphometry → Quantify Layers...*

An options dialog appears:

| Option | Effect |
|---|---|
| Show colour-coded layer overlay | Adds a vector overlay (see Overlay section) |
| Show per-lobule transparent fills | Adds distinct semitransparent fills for each lobule |
| Show ImageJ Results Table | Displays the measurement table interactively |
| Export CSV | Saves a UTF-8 comma-separated file |
| Export Excel (.xlsx) | Saves a formatted workbook |

If either export is selected, you will be prompted for a save directory. Files are named
after the image title (with non-alphanumeric characters replaced by underscores).

---

## Output table format

```
Measurement  | Cerebellum  | Grey Matter | Granular Layer | Molecular Layer | Purkinje
Area         | Total area  | Grey area   | Granular area  | Molecular area  |
Length       |             |             |                |                 | Total length
2Cb          |             |             | Area           | Area            | Length
3Cb          |             |             | Area           | Area            | Length
4/5Cb        |             |             | Area           | Area            | Length
6Cb          |             |             | Area           | Area            | Length
7Cb          |             |             | Area           | Area            | Length
8Cb          |             |             | Area           | Area            | Length
9Cb          |             |             | Area           | Area            | Length
10Cb         |             |             | Area           | Area            | Length
```

Areas are in calibrated area units (e.g. µm²); length is in calibrated linear units (e.g. µm).
Empty cells carry no measurement for that row/column combination.

---

## Overlay colours

| Layer | Colour |
|---|---|
| Grey Matter | Blue |
| Granular Layer | Green |
| Molecular Layer | Yellow |
| Purkinje line | Red |
| Partition boundaries | White |
| Per-lobule fills (optional) | 8 distinct hues |

The overlay is purely vector (non-destructive). To remove it: *Image → Overlay → Remove Overlay*.

---

## Architecture

```
org.cerebellum.morphometry
│   CerebellarMorphometryPlugin   ← ij.plugin.PlugIn entry point
│
├── model/
│   ├── LayerSet                  validated, typed input ROI bundle
│   ├── ConstructedLayers         three Boolean-derived whole-cerebellum shapes
│   ├── PartitionSet              eight lobule regions + Purkinje arc-length bounds
│   ├── MorphometryResults        final numbers (areas, lengths, per-subsection)
│   └── ValidationException       carries all problems found during validation
│
├── geometry/
│   ├── ROIValidator              name/type/nesting checks → LayerSet
│   ├── BooleanROIProcessor       defensive-copy ShapeRoi AND/OR/NOT + area measurement
│   ├── GeometryUtils             vector math, polyline arc-length, projection
│   ├── LayerConstructor          cerebellum − WM → Grey/Granular/Molecular
│   ├── FissurePartitioner        7 fissures → 8 half-plane partitions
│   ├── PartitionClipper          clips granular/molecular into per-partition shapes
│   └── PurkinjeLengthCalculator  calibrated arc-length, total and per-partition
│
├── measurement/
│   └── MeasurementEngine         orchestrates the full pipeline → MorphometryResults
│
├── export/
│   └── SpreadsheetExporter       ResultsTable + CSV + XLSX (exact spec layout)
│
└── visualization/
    └── OverlayRenderer           colour-coded vector overlay
```

---

## Partitioning algorithm (summary)

1. Each fissure's Purkinje-proximal endpoint is projected onto the Purkinje polyline to
   determine its arc-length position. Sorting by arc-length gives the anatomical
   (lobule-2→lobule-10) order without any image-orientation assumptions.
2. Each fissure is extended in a straight line continuing its own pial→Purkinje direction,
   far enough to clear the entire cerebellum bounding box in both directions.
3. The extended line is thickened into a large half-plane polygon. Intersecting that
   polygon with the cerebellum ROI (`ShapeRoi.and`) gives the part of the cerebellum on
   the lobule-10 side of the cut.
4. The eight partitions are consecutive differences of these half-planes:
   - Subsection 1 (2Cb) = Cerebellum − halfPlane[0]
   - Subsection k = halfPlane[k−2] − halfPlane[k−1]   (k = 2…7)
   - Subsection 8 (10Cb) = halfPlane[6]
5. Per-partition Purkinje length = calibrated arc-length between the two bounding
   fissures' attachment points (no separate polyline clipping needed).

---

## Troubleshooting

| Problem | Cause / fix |
|---|---|
| *"The ROI Manager is empty"* | Add all required ROIs before running |
| *"More than one ROI matches Cerebellum"* | Rename or remove the extra ROI |
| *"Missing the WhiteMatter ROI"* | Add a closed polygon named containing "white" or "WM" |
| *"Expected exactly 7 fissure ROIs"* | Ensure all seven fissure ROIs have "fissure" in their name |
| *"WhiteMatter ROI is a polyline"* | Re-trace as a closed polygon in FIJI |
| *"Granular+WM is not fully inside Cerebellum"* | Redraw Granular+WM so it is contained within the Cerebellum outline |
| Per-partition areas don't add up | Check that the fissure lines actually reach the Purkinje line; very short or reversed fissures may be detected as not touching the Purkinje layer |
| Overlay looks wrong | Verify ROI nesting; run with subsection fills enabled to inspect the partition boundaries against the tissue |

---

## License
MIT — see `LICENSE` for details. Dependencies (ImageJ, SciJava, Apache POI) retain their
own respective licences.
